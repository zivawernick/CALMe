#!/usr/bin/env python3
"""
FAQ Bucket Results Dashboard
A web-based dashboard for analyzing FAQ bucket clustering results.
"""

import os
import logging
from typing import List
from flask import Flask, render_template, jsonify
from routes import register_routes
from config import config

# Configure logging based on config
logging.basicConfig(
    level=getattr(logging, config.LOG_LEVEL),
    format=config.LOG_FORMAT
)
logger: logging.Logger = logging.getLogger(__name__)

def create_app() -> Flask:
    """Create and configure the Flask application."""
    app: Flask = Flask(__name__)
    
    # Configure app using config
    app.config.update(config.get_flask_config())
    
    # Validate configuration and log warnings
    warnings: List[str] = config.validate_config()
    for warning in warnings:
        logger.warning(warning)
    
    # Register routes
    register_routes(app)
    
    # Main page route
    @app.route('/')
    def index() -> str:
        """Main dashboard page."""
        try:
            logger.info("Serving main dashboard page")
            return render_template('index.html')
        except Exception as e:
            logger.error(f"Error serving main page: {e}")
            return "Error loading dashboard", 500
    
    # Error handlers
    @app.errorhandler(400)
    def bad_request(error: Exception) -> tuple[str, int]:
        """Handle bad request errors."""
        logger.warning(f"Bad request: {error}")
        return jsonify({
            'success': False,
            'error': 'Bad request - invalid data provided'
        }), 400
    
    @app.errorhandler(404)
    def not_found(error: Exception) -> tuple[str, int]:
        """Handle not found errors."""
        logger.warning(f"Not found: {error}")
        return jsonify({
            'success': False,
            'error': 'Resource not found'
        }), 404
    
    @app.errorhandler(500)
    def internal_error(error: Exception) -> tuple[str, int]:
        """Handle internal server errors."""
        logger.error(f"Internal server error: {error}")
        return jsonify({
            'success': False,
            'error': 'Internal server error - please try again later'
        }), 500
    
    @app.errorhandler(Exception)
    def handle_exception(error: Exception) -> tuple[str, int]:
        """Handle any unhandled exceptions."""
        logger.error(f"Unhandled exception: {error}")
        return jsonify({
            'success': False,
            'error': 'An unexpected error occurred'
        }), 500
    
    logger.info("Flask application created successfully")
    return app

# Create the app instance
app: Flask = create_app()

if __name__ == '__main__':
    try:
        logger.info("Starting FAQ Bucket Dashboard...")
        logger.info(f"Dashboard will be available at: http://{config.HOST}:{config.PORT}")
        logger.info(f"Environment: {os.getenv('DASHBOARD_ENV', 'development')}")
        logger.info(f"Debug mode: {config.DEBUG}")
        
        app.run(
            debug=config.DEBUG,
            host=config.HOST, 
            port=config.PORT
        )
    except Exception as e:
        logger.error(f"Failed to start dashboard: {e}")
        raise
