#!/usr/bin/env python3
"""
API route handlers for the FAQ Bucket Dashboard.
"""

import os
import logging
import tempfile
import pandas as pd
from typing import Dict, Any, Tuple
from flask import request, jsonify, send_file, Flask
from utils import (
    validate_directory, load_bucket_data, get_bucket_questions,
    create_success_response, create_error_response, paginate_dataframe,
    load_csv_safely, convert_numpy_types
)
from services import PDFReportService, DataProcessingService

logger: logging.Logger = logging.getLogger(__name__)

# Initialize services
pdf_service: PDFReportService = PDFReportService()
data_service: DataProcessingService = DataProcessingService()

def register_routes(app: Flask) -> None:
    """Register all API routes with the Flask app."""
    
    @app.route('/api/validate_directory', methods=['POST'])
    def api_validate_directory() -> Tuple[Dict[str, Any], int]:
        """API endpoint to validate a directory."""
        try:
            data: Dict[str, Any] = request.get_json()
            if not data:
                return create_error_response('No JSON data received', 400)
            
            directory_path: str = data.get('directory_path', '')
            if not directory_path:
                return create_error_response('No directory path provided', 400)
            
            logger.info(f"Validating directory: {directory_path}")
            
            is_valid: bool
            message: str
            is_valid, message = validate_directory(directory_path)
            
            return create_success_response({
                'valid': is_valid,
                'message': message
            })
            
        except Exception as e:
            logger.error(f"Error in directory validation endpoint: {e}")
            return create_error_response(f'Validation error: {str(e)}', 500)
    
    @app.route('/api/load_data', methods=['POST'])
    def api_load_data() -> Tuple[Dict[str, Any], int]:
        """API endpoint to load data from a directory."""
        try:
            data: Dict[str, Any] = request.get_json()
            if not data:
                return create_error_response('No JSON data received', 400)
            
            directory_path: str = data.get('directory_path', '')
            if not directory_path:
                return create_error_response('No directory path provided', 400)
            
            logger.info(f"Loading data from directory: {directory_path}")
            
            summary_df: pd.DataFrame
            assignments_df: pd.DataFrame
            summary_df, assignments_df = load_bucket_data(directory_path)
            
            # Prepare chart data
            chart_data: Dict[str, Any] = data_service.prepare_chart_data(summary_df)
            
            # Prepare summary records
            summary_records: list = data_service.prepare_summary_records(summary_df)
            
            logger.info(f"Data loaded successfully: {len(summary_df)} buckets, {summary_df['n_items'].sum()} questions")
            
            return create_success_response({
                'summary': summary_records,
                'chart_data': chart_data,
                'total_buckets': int(len(summary_df)),
                'total_questions': int(summary_df['n_items'].sum())
            })
            
        except Exception as e:
            logger.error(f"Error in load data endpoint: {e}")
            return create_error_response(f'Error loading data: {str(e)}', 500)
    
    @app.route('/api/bucket_details', methods=['POST'])
    def api_bucket_details() -> Tuple[Dict[str, Any], int]:
        """API endpoint to get details for a specific bucket."""
        try:
            data: Dict[str, Any] = request.get_json()
            if not data:
                return create_error_response('No JSON data received', 400)
            
            directory_path: str = data.get('directory_path', '')
            bucket_id: Any = data.get('bucket_id')
            page: int = data.get('page', 1)
            page_size: int = data.get('page_size', 20)
            
            if not directory_path:
                return create_error_response('No directory path provided', 400)
            
            if bucket_id is None:
                return create_error_response('No bucket ID provided', 400)
            
            logger.info(f"Getting details for bucket {bucket_id} from directory: {directory_path}")
            
            summary_df: pd.DataFrame
            assignments_df: pd.DataFrame
            summary_df, assignments_df = load_bucket_data(directory_path)
            
            # Get bucket summary
            bucket_summary: pd.Series = summary_df[summary_df['bucket_id'] == bucket_id]
            if len(bucket_summary) == 0:
                return create_error_response(f'Bucket {bucket_id} not found', 404)
            
            bucket_summary = bucket_summary.iloc[0]
            
            # Get bucket questions with pagination
            questions_data: Dict[str, Any] = get_bucket_questions(bucket_id, assignments_df, page, page_size)
            
            # Get canonical Q&A using utility function
            canonical_path: str = os.path.join(directory_path, 'faq_bucket_canonical_qna.csv')
            canonical_df: pd.DataFrame = load_csv_safely(canonical_path)
            canonical_row: pd.DataFrame = canonical_df[canonical_df['bucket_id'] == bucket_id]
            
            canonical_data: Dict[str, Any] = canonical_row.iloc[0].to_dict() if len(canonical_row) > 0 else {}
            
            # Convert numpy types to Python native types for JSON serialization
            bucket_summary_dict: Dict[str, Any] = convert_numpy_types(bucket_summary.to_dict())
            
            logger.info(f"Bucket details retrieved successfully for bucket {bucket_id}")
            
            return create_success_response({
                'bucket_summary': bucket_summary_dict,
                'questions_data': questions_data,
                'canonical_data': canonical_data
            })
            
        except Exception as e:
            logger.error(f"Error in bucket details endpoint: {e}")
            return create_error_response(f'Error retrieving bucket details: {str(e)}', 500)
    
    @app.route('/api/generate_pdf', methods=['POST'])
    def api_generate_pdf() -> Any:
        """API endpoint to generate PDF report."""
        try:
            data: Dict[str, Any] = request.get_json()
            if not data:
                return create_error_response('No JSON data received', 400)
            
            directory_path: str = data.get('directory_path', '')
            bucket_count: int = data.get('bucket_count', 10)
            
            # Get view state parameters
            current_page: int = data.get('current_page', 1)
            total_pages: int = data.get('total_pages', 1)
            similarity_filters: Dict[str, Any] = data.get('similarity_filters', {})
            search_term: str = data.get('search_term', '')
            chart_bucket_count: int = data.get('chart_bucket_count', 20)
            current_chart_data: Dict[str, Any] = data.get('current_chart_data', {})
            chart_image: str = data.get('chart_image', '')
            
            if not directory_path:
                return create_error_response('No directory path provided', 400)
            
            logger.info(f"Generating PDF for directory: {directory_path}, bucket count: {bucket_count}")
            logger.info(f"View state: page {current_page}/{total_pages}, filters: {similarity_filters}, search: '{search_term}'")
            
            # Create temporary file for PDF
            with tempfile.NamedTemporaryFile(suffix='.pdf', delete=False) as tmp_file:
                pdf_service.generate_pdf_report(
                    directory_path, 0, tmp_file, 
                    current_page, total_pages, similarity_filters, 
                    search_term, chart_bucket_count, current_chart_data, chart_image
                )
                tmp_file_path: str = tmp_file.name
            
            logger.info(f"PDF generated successfully at: {tmp_file_path}")
            
            # Generate descriptive filename based on view state
            filename_parts: list = [f'faq_bucket_report']
            
            if search_term:
                filename_parts.append(f'search_{search_term[:20]}')
            
            if similarity_filters:
                active_filters: list = [f"{range_name}" for range_name, is_active in similarity_filters.items() if is_active]
                if active_filters:
                    filename_parts.append(f'filters_{"_".join(active_filters)}')
            
            if total_pages > 1:
                filename_parts.append(f'page_{current_page}')
            
            # Use actual bucket count from chart data
            actual_bucket_count: int = len(current_chart_data.get("bucket_ids", [])) if current_chart_data else 0
            if actual_bucket_count > 0:
                filename_parts.append(f'{actual_bucket_count}_buckets')
            else:
                filename_parts.append('current_view')
            
            filename: str = f"{'_'.join(filename_parts)}.pdf"
            
            logger.info(f"Returning PDF with filename: {filename}")
            
            # Return the PDF file
            return send_file(
                tmp_file_path,
                as_attachment=True,
                download_name=filename,
                mimetype='application/pdf'
            )
            
        except Exception as e:
            logger.error(f"Error in PDF generation endpoint: {str(e)}")
            import traceback
            traceback.print_exc()
            return create_error_response(f'Error generating PDF: {str(e)}', 500)
