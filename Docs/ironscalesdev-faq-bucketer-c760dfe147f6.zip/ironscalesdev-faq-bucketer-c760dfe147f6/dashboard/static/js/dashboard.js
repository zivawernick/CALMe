// Dashboard JavaScript functionality
let currentDirectory = '';
let currentData = null;
let bucketSizeChart = null;
let similarityChart = null;
let currentPage = 1;
let totalPages = 1;

// Initialize dashboard
document.addEventListener('DOMContentLoaded', function() {
    // Set default directory if available
    const defaultDir = document.getElementById('directoryInput').value;
    if (defaultDir) {
        loadData(defaultDir);
    }

    // Event listeners
    document.getElementById('loadDataBtn').addEventListener('click', function() {
        const directory = document.getElementById('directoryInput').value.trim();
        if (directory) {
            loadData(directory);
        } else {
            showMessage('Please enter a directory path first', 'error');
        }
    });

    document.getElementById('generatePdfBtn').addEventListener('click', function() {
        generatePdfReport();
    });

    document.getElementById('searchInput').addEventListener('input', function() {
        filterBuckets(this.value);
    });

    // Add event listeners for similarity filters
    document.querySelectorAll('.similarity-filter').forEach(button => {
        button.addEventListener('click', function() {
            const isActive = this.dataset.active === 'true';
            this.dataset.active = !isActive;
            
            // Update button appearance
            if (this.dataset.active === 'true') {
                this.classList.remove('btn-outline-secondary');
                this.classList.add(this.classList.contains('btn-outline-danger') ? 'btn-outline-danger' : 
                                this.classList.contains('btn-outline-warning') ? 'btn-outline-warning' : 'btn-outline-primary');
            } else {
                this.classList.remove('btn-outline-danger', 'btn-outline-warning', 'btn-outline-primary');
                this.classList.add('btn-outline-secondary');
            }
            
            // Reset pagination when filters change
            currentPage = 1;
            
            // Regenerate chart if data is loaded
            if (currentData) {
                createBucketSizeChart(currentData.chart_data);
            }
        });
    });

    // Add event listener for bucket count selector
    document.getElementById('bucketCountSelect').addEventListener('change', function() {
        // Reset to first page when changing bucket count
        currentPage = 1;
        // Regenerate chart if data is loaded
        if (currentData) {
            createBucketSizeChart(currentData.chart_data);
        }
    });

    // Add event listeners for pagination buttons
    document.getElementById('prevPageBtn').addEventListener('click', function() {
        if (currentPage > 1) {
            currentPage--;
            if (currentData) {
                createBucketSizeChart(currentData.chart_data);
            }
        }
    });

    document.getElementById('nextPageBtn').addEventListener('click', function() {
        if (currentPage < totalPages) {
            currentPage++;
            if (currentData) {
                createBucketSizeChart(currentData.chart_data);
            }
        }
    });

    // Enter key support for directory input
    document.getElementById('directoryInput').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            document.getElementById('loadDataBtn').click();
        }
    });
});

function loadData(directory) {
    showLoading(true);
    currentDirectory = directory;
    // Reset pagination when loading new data
    currentPage = 1;

    // Validate directory first
    fetch('/api/validate_directory', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ directory_path: directory })
    })
    .then(response => response.json())
    .then(data => {
        if (data.valid) {
            return fetch('/api/load_data', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ directory_path: directory })
            });
        } else {
            throw new Error(data.message);
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            currentData = data;
            displayDashboard(data);
            showMessage('Data loaded successfully!', 'success');
            document.getElementById('generatePdfBtn').disabled = false;
        } else {
            throw new Error(data.error);
        }
    })
    .catch(error => {
        showMessage('Error: ' + error.message, 'error');
        showLoading(false);
    });
}

function displayDashboard(data) {
    console.log('displayDashboard called with data:', data);
    
    // Reset pagination when displaying new dashboard
    currentPage = 1;
    
    // Update statistics
    document.getElementById('totalBuckets').textContent = data.total_buckets;
    document.getElementById('totalQuestions').textContent = data.total_questions;
    
    const avgBucketSize = (data.total_questions / data.total_buckets).toFixed(1);
    document.getElementById('avgBucketSize').textContent = avgBucketSize;
    
    const avgSimilarity = (data.summary.reduce((sum, bucket) => sum + bucket.median_similarity, 0) / data.total_buckets).toFixed(4);
    document.getElementById('avgSimilarity').textContent = avgSimilarity;

    // Display bucket list first
    displayBucketList(data.summary);

    // Create charts with a small delay to ensure DOM is ready
    setTimeout(() => {
        console.log('Creating charts after timeout...');
        createBucketSizeChart(data.chart_data);
        createSimilarityChart(data.chart_data);
        
        // Force dashboard content to be visible
        document.getElementById('dashboardContent').style.display = 'block';
        console.log('Charts created, dashboard content display style:', document.getElementById('dashboardContent').style.display);
    }, 100);

    showLoading(false);
}

// Helper function to get color based on similarity score (colorblind-friendly)
function getSimilarityColor(similarity) {
    if (similarity >= 0.6 && similarity < 0.7) {
        return '#ff6384';  // Red (least similar)
    } else if (similarity >= 0.7 && similarity < 0.8) {
        return '#ffa500';  // Orange
    } else if (similarity >= 0.8 && similarity < 0.9) {
        return '#ffcd56';  // Yellow
    } else if (similarity >= 0.9 && similarity <= 1.0) {
        return '#36a2eb';  // Blue (most similar)
    } else {
        return '#808080'; // Gray for outliers
    }
}

// Helper function to get border color with better contrast
function getSimilarityBorderColor(similarity) {
    if (similarity >= 0.6 && similarity < 0.7) {
        return 'rgba(220, 53, 69, 1)';  // Darker red
    } else if (similarity >= 0.7 && similarity < 0.8) {
        return 'rgba(220, 118, 51, 1)';  // Darker orange
    } else if (similarity >= 0.8 && similarity < 0.9) {
        return 'rgba(220, 170, 51, 1)';  // Darker yellow
    } else if (similarity >= 0.9 && similarity <= 1.0) {
        return 'rgba(51, 122, 183, 1)';  // Darker blue
    } else {
        return 'rgba(108, 117, 125, 1)'; // Darker gray
    }
}

// Helper function to get active similarity filters
function getActiveSimilarityFilters() {
    const filters = {};
    document.querySelectorAll('.similarity-filter').forEach(button => {
        const range = button.dataset.range;
        const isActive = button.dataset.active === 'true';
        filters[range] = isActive;
    });
    return filters;
}

// Helper function to get current chart data (what's actually displayed)
function getCurrentChartData() {
    if (!currentData || !currentData.chart_data) {
        return null;
    }

    // Get active similarity filters
    const activeFilters = getActiveSimilarityFilters();
    
    // Filter data based on active similarity ranges
    const filteredData = filterDataBySimilarity(currentData.chart_data, activeFilters);
    
    // Get current page data
    const currentPageData = getTopNBuckets(filteredData);
    
    return {
        labels: currentPageData.labels,
        sizes: currentPageData.sizes,
        similarities: currentPageData.similarities,
        example_questions: currentPageData.example_questions,
        bucket_ids: currentPageData.bucket_ids,
        total_filtered_buckets: filteredData.labels.length,
        current_page: currentPage,
        total_pages: totalPages
    };
}

// Helper function to capture current chart as base64 image
function captureChartAsImage() {
    if (!bucketSizeChart) {
        return null;
    }
    
    try {
        // Get the canvas element
        const canvas = document.getElementById('bucketSizeChart');
        if (!canvas) {
            return null;
        }
        
        // Convert canvas to base64 image
        const imageData = canvas.toDataURL('image/png');
        return imageData;
    } catch (error) {
        console.error('Error capturing chart:', error);
        return null;
    }
}

// Helper function to update pagination UI
function updatePaginationUI() {
    const bucketCount = parseInt(document.getElementById('bucketCountSelect').value);
    const startBucket = (currentPage - 1) * bucketCount + 1;
    const endBucket = Math.min(currentPage * bucketCount, currentData.chart_data.labels.length);
    
    // Update pagination info
    document.getElementById('currentPageInfo').textContent = currentPage;
    document.getElementById('totalPagesInfo').textContent = totalPages;
    document.getElementById('currentRangeInfo').textContent = `${startBucket}-${endBucket}`;
    document.getElementById('totalBucketsInfo').textContent = currentData.chart_data.labels.length;
    
    // Update pagination buttons
    document.getElementById('prevPageBtn').disabled = currentPage <= 1;
    document.getElementById('nextPageBtn').disabled = currentPage >= totalPages;
    
    // Update chart title dynamically
    updateChartTitle(startBucket, endBucket);
}

// Helper function to update chart title dynamically
function updateChartTitle(startBucket, endBucket) {
    const chartTitle = document.getElementById('chartTitle');
    
    if (currentPage === 1) {
        // First page: show "Top Buckets by Size"
        chartTitle.textContent = 'Top Buckets by Size';
    } else {
        // Other pages: show "Buckets X-Y by Size"
        chartTitle.textContent = `Buckets ${startBucket}-${endBucket} by Size`;
    }
}

// Helper function to filter data by similarity ranges
function filterDataBySimilarity(chartData, activeFilters) {
    const filtered = {
        labels: [],
        sizes: [],
        similarities: [],
        example_questions: [],
        bucket_ids: []
    };

    for (let i = 0; i < chartData.labels.length; i++) {
        const similarity = chartData.similarities[i];
        let shouldInclude = false;

        if (similarity >= 0.6 && similarity < 0.7 && activeFilters['0.6-0.7']) shouldInclude = true;
        else if (similarity >= 0.7 && similarity < 0.8 && activeFilters['0.7-0.8']) shouldInclude = true;
        else if (similarity >= 0.8 && similarity < 0.9 && activeFilters['0.8-0.9']) shouldInclude = true;
        else if (similarity >= 0.9 && similarity <= 1.0 && activeFilters['0.9-1.0']) shouldInclude = true;

        if (shouldInclude) {
            filtered.labels.push(chartData.labels[i]);
            filtered.sizes.push(chartData.sizes[i]);
            filtered.similarities.push(chartData.similarities[i]);
            filtered.example_questions.push(chartData.example_questions[i]);
            filtered.bucket_ids.push(chartData.bucket_ids[i]);
        }
    }

    return filtered;
}

// Helper function to get top N buckets from filtered data with pagination
function getTopNBuckets(filteredData) {
    // Get the selected bucket count
    const bucketCount = parseInt(document.getElementById('bucketCountSelect').value);
    
    // Create array of indices sorted by size (descending)
    const indices = Array.from({length: filteredData.sizes.length}, (_, i) => i)
        .sort((a, b) => filteredData.sizes[b] - filteredData.sizes[a]);

    // Calculate pagination
    totalPages = Math.ceil(indices.length / bucketCount);
    currentPage = Math.min(currentPage, totalPages); // Ensure current page is valid
    if (currentPage < 1) currentPage = 1;

    // Calculate start and end indices for current page
    const startIndex = (currentPage - 1) * bucketCount;
    const endIndex = startIndex + bucketCount;

    // Take buckets for current page
    const pageIndices = indices.slice(startIndex, endIndex);

    // Extract data for current page buckets
    return {
        labels: pageIndices.map(i => filteredData.labels[i]),
        sizes: pageIndices.map(i => filteredData.sizes[i]),
        similarities: pageIndices.map(i => filteredData.similarities[i]),
        example_questions: pageIndices.map(i => filteredData.example_questions[i]),
        bucket_ids: pageIndices.map(i => filteredData.bucket_ids[i])
    };
}

function createBucketSizeChart(chartData) {
    const canvas = document.getElementById('bucketSizeChart');
    const ctx = canvas.getContext('2d');
    
    if (bucketSizeChart) {
        bucketSizeChart.destroy();
    }

    console.log('Creating bucket size chart with data:', chartData);

    // Get active similarity filters
    const activeFilters = getActiveSimilarityFilters();
    
    // Filter data based on active similarity ranges
    const filteredData = filterDataBySimilarity(chartData, activeFilters);
    
    // Take top N buckets from filtered data
    const topNData = getTopNBuckets(filteredData);
    
    // Generate individual colors for each bar based on similarity
    const backgroundColors = topNData.similarities.map(sim => getSimilarityColor(sim));
    const borderColors = topNData.similarities.map(sim => getSimilarityBorderColor(sim));

    // Store similarities data in the chart instance for tooltip access
    const chartInstance = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: topNData.labels.map(label => label.length > 30 ? label.substring(0, 30) + '...' : label),
            datasets: [{
                label: 'Number of Questions',
                data: topNData.sizes,
                backgroundColor: backgroundColors,
                borderColor: borderColors,
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            onClick: function(event, elements) {
                if (elements.length > 0) {
                    const dataIndex = elements[0].index;
                    // Get the bucket data for the clicked bar
                    const bucketId = chartInstance.bucketIds[dataIndex];
                    const bucketLabel = chartInstance.data.labels[dataIndex];
                    
                    if (bucketId !== undefined) {
                        showBucketDetails(bucketId);
                    }
                }
            },
            onHover: function(event, elements) {
                // Change cursor to pointer only when hovering over bars
                if (elements.length > 0) {
                    event.native.target.style.cursor = 'pointer';
                } else {
                    event.native.target.style.cursor = 'default';
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Questions per Bucket'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Bucket Labels'
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        title: function(context) {
                            const dataIndex = context[0].dataIndex;
                            // Access example questions from chart data
                            const exampleQuestions = chartData.example_questions;
                            const exampleQuestion = exampleQuestions[dataIndex];
                            // Return full question - Chart.js will handle wrapping
                            return exampleQuestion || 'No example question';
                        },
                        afterBody: function(context) {
                            const dataIndex = context[0].dataIndex;
                            // Access similarities from the chart instance
                            const similarities = chartInstance.similarities;
                            const similarity = similarities[dataIndex];
                            return `Similarity: ${similarity.toFixed(4)}`;
                        }
                    }
                }
            }
        }
    });
    
    // Store similarities, example questions, and bucket IDs data in the chart instance for tooltip access
    chartInstance.similarities = topNData.similarities;
    chartInstance.exampleQuestions = topNData.example_questions;
    chartInstance.bucketIds = topNData.bucket_ids;
    
    bucketSizeChart = chartInstance;
    
    // Update pagination UI
    updatePaginationUI();
}

function createSimilarityChart(chartData) {
    const canvas = document.getElementById('similarityChart');
    const ctx = canvas.getContext('2d');
    
    if (similarityChart) {
        similarityChart.destroy();
    }

    console.log('Creating similarity chart with data:', chartData);

    // Group similarities into ranges
    const ranges = {
        '0.6-0.7': 0,
        '0.7-0.8': 0,
        '0.8-0.9': 0,
        '0.9-1.0': 0
    };

    chartData.similarities.forEach(sim => {
        if (sim >= 0.6 && sim < 0.7) ranges['0.6-0.7']++;
        else if (sim >= 0.7 && sim < 0.8) ranges['0.7-0.8']++;
        else if (sim >= 0.8 && sim < 0.9) ranges['0.8-0.9']++;
        else if (sim >= 0.9 && sim <= 1.0) ranges['0.9-1.0']++;
    });

    similarityChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: Object.keys(ranges),
            datasets: [{
                data: Object.values(ranges),
                backgroundColor: [
                    'rgba(255, 99, 132, 0.8)',  // Red (least similar)
                    'rgba(255, 165, 0, 0.8)',   // Orange
                    'rgba(255, 205, 86, 0.8)',  // Yellow
                    'rgba(54, 162, 235, 0.8)'   // Blue (most similar)
                ],
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 15,
                        usePointStyle: true,
                        pointStyle: 'circle'
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.parsed;
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = ((value / total) * 100).toFixed(1);
                            return `${label}: ${value} buckets (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
}

function displayBucketList(buckets) {
    const container = document.getElementById('bucketList');
    container.innerHTML = '';

    buckets.forEach(bucket => {
        const bucketCard = document.createElement('div');
        bucketCard.className = 'card bucket-card mb-3';
        
        // Get the similarity color for this bucket
        const similarityColor = getSimilarityColor(bucket.median_similarity);
        
        // Set the CSS custom property for the gradient
        bucketCard.style.setProperty('--similarity-color', similarityColor);
        
        // Debug: log the color being applied
        console.log(`Bucket ${bucket.bucket_id}: similarity ${bucket.median_similarity}, color: ${similarityColor}`);
        
        bucketCard.innerHTML = `
            <div class="card-body">
                <div class="row">
                    <div class="col-md-8">
                        <h6 class="card-title">Bucket ${bucket.bucket_id}: ${bucket.bucket_label}</h6>
                        <p class="card-text text-muted">${bucket.example_question}</p>
                    </div>
                    <div class="col-md-4 text-end">
                        <span class="badge bg-primary fs-6">${bucket.n_items} questions</span>
                        <br>
                        <small class="text-muted">Similarity: ${bucket.median_similarity.toFixed(4)}</small>
                    </div>
                </div>
            </div>
        `;

        bucketCard.addEventListener('click', () => {
            showBucketDetails(bucket.bucket_id);
        });

        container.appendChild(bucketCard);
    });
}

function filterBuckets(searchTerm) {
    if (!currentData) return;

    const filteredBuckets = currentData.summary.filter(bucket => 
        bucket.bucket_label.toLowerCase().includes(searchTerm.toLowerCase()) ||
        bucket.example_question.toLowerCase().includes(searchTerm.toLowerCase())
    );

    displayBucketList(filteredBuckets);
}

function showBucketDetails(bucketId) {
    const modal = new bootstrap.Modal(document.getElementById('bucketModal'));
    const modalContent = document.getElementById('bucketModalContent');
    
    modalContent.innerHTML = '<div class="text-center"><div class="spinner-border" role="status"></div></div>';
    modal.show();

    fetch('/api/bucket_details', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
            directory_path: currentDirectory,
            bucket_id: bucketId,
            page: 1,
            page_size: 20
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            displayBucketModal(data);
        } else {
            modalContent.innerHTML = `<div class="alert alert-danger">Error: ${data.error}</div>`;
        }
    })
    .catch(error => {
        modalContent.innerHTML = `<div class="alert alert-danger">Error: ${error.message}</div>`;
    });
}

function displayBucketModal(data) {
    const { bucket_summary, questions_data, canonical_data } = data;
    const modalContent = document.getElementById('bucketModalContent');
    const modalTitle = document.getElementById('bucketModalLabel');

    modalTitle.textContent = `Bucket ${bucket_summary.bucket_id}: ${bucket_summary.bucket_label}`;

    let questionsHtml = '';
    questions_data.questions.forEach(question => {
        questionsHtml += `
            <div class="question-item">
                <strong>Q:</strong> ${question.question_text}
                <br>
                <small class="text-muted">Source Row: ${question.source_row_index}</small>
            </div>
        `;
    });

    const paginationHtml = createPaginationHtml(questions_data);

    modalContent.innerHTML = `
        <div class="row mb-3">
            <div class="col-md-6">
                <h6>Bucket Statistics</h6>
                <ul class="list-unstyled">
                    <li><strong>Questions:</strong> ${bucket_summary.n_items}</li>
                    <li><strong>Median Similarity:</strong> ${bucket_summary.median_similarity.toFixed(4)}</li>
                    <li><strong>Example Question:</strong> ${bucket_summary.example_question}</li>
                </ul>
            </div>
            <div class="col-md-6">
                <h6>Canonical Question</h6>
                <p>${canonical_data.representative_question || 'Not available'}</p>
            </div>
        </div>

        <div class="canonical-answer">
            <h6>Canonical Answer</h6>
            <p>${formatCanonicalAnswer(canonical_data.canonical_answer || 'Not available')}</p>
        </div>

        <h6>Questions in this Bucket (${questions_data.total} total)</h6>
        <div class="mb-3">
            <label for="pageSizeSelect" class="form-label">Questions per page:</label>
            <select class="form-select form-select-sm" id="pageSizeSelect" style="width: 100px;">
                <option value="10">10</option>
                <option value="20" selected>20</option>
                <option value="50">50</option>
                <option value="100">100</option>
            </select>
        </div>
        ${questionsHtml}
        ${paginationHtml}
    `;

    // Add event listeners for pagination and page size
    document.getElementById('pageSizeSelect').addEventListener('change', function() {
        loadBucketQuestions(bucket_summary.bucket_id, 1, parseInt(this.value));
    });

    // Add pagination event listeners
    const paginationLinks = modalContent.querySelectorAll('.pagination-link');
    paginationLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const page = parseInt(this.dataset.page);
            const pageSize = parseInt(document.getElementById('pageSizeSelect').value);
            loadBucketQuestions(bucket_summary.bucket_id, page, pageSize);
        });
    });
}

function createPaginationHtml(questionsData) {
    if (questionsData.total_pages <= 1) return '';

    let paginationHtml = '<nav><ul class="pagination justify-content-center">';
    
    // Previous button
    if (questionsData.page > 1) {
        paginationHtml += `<li class="page-item"><a class="page-link pagination-link" href="#" data-page="${questionsData.page - 1}">Previous</a></li>`;
    }

    // Page numbers
    for (let i = 1; i <= questionsData.total_pages; i++) {
        if (i === questionsData.page) {
            paginationHtml += `<li class="page-item active"><span class="page-link">${i}</span></li>`;
        } else {
            paginationHtml += `<li class="page-item"><a class="page-link pagination-link" href="#" data-page="${i}">${i}</a></li>`;
        }
    }

    // Next button
    if (questionsData.page < questionsData.total_pages) {
        paginationHtml += `<li class="page-item"><a class="page-link pagination-link" href="#" data-page="${questionsData.page + 1}">Next</a></li>`;
    }

    paginationHtml += '</ul></nav>';
    return paginationHtml;
}

function loadBucketQuestions(bucketId, page, pageSize) {
    fetch('/api/bucket_details', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
            directory_path: currentDirectory,
            bucket_id: bucketId,
            page: page,
            page_size: pageSize
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Update the questions display in the modal
            const questionsContainer = document.querySelector('#bucketModalContent .question-item').parentNode;
            let questionsHtml = '';
            
            data.questions_data.questions.forEach(question => {
                questionsHtml += `
                    <div class="question-item">
                        <strong>Q:</strong> ${question.question_text}
                        <br>
                        <small class="text-muted">Source Row: ${question.source_row_index}</small>
                    </div>
                `;
            });

            questionsContainer.innerHTML = questionsHtml;
            
            // Update pagination
            const paginationContainer = document.querySelector('#bucketModalContent nav');
            paginationContainer.innerHTML = createPaginationHtml(data.questions_data);
            
            // Re-add pagination event listeners
            const paginationLinks = document.querySelectorAll('.pagination-link');
            paginationLinks.forEach(link => {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    const page = parseInt(this.dataset.page);
                    const pageSize = parseInt(document.getElementById('pageSizeSelect').value);
                    loadBucketQuestions(bucketId, page, pageSize);
                });
            });
        }
    })
    .catch(error => {
        console.error('Error loading questions:', error);
    });
}

function generatePdfReport() {
    if (!currentDirectory) {
        showMessage('Please load data first', 'error');
        return;
    }

    // Show loading state
    const btn = document.getElementById('generatePdfBtn');
    const originalText = 'Generate Report from Current View';
    btn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status"></span> Generating...';
    btn.disabled = true;

    // Capture current view state
    const currentViewState = {
        directory_path: currentDirectory,
        bucket_count: 0, // Not used anymore, but keeping for backward compatibility
        // Current pagination state
        current_page: currentPage,
        total_pages: totalPages,
        // Current similarity filters
        similarity_filters: getActiveSimilarityFilters(),
        // Current search term
        search_term: document.getElementById('searchInput').value.trim(),
        // Current bucket count selector
        chart_bucket_count: parseInt(document.getElementById('bucketCountSelect').value),
        // Current chart data (what's actually displayed)
        current_chart_data: getCurrentChartData(),
        // Current chart image
        chart_image: captureChartAsImage()
    };

    // Use fetch API with proper JSON content type
    fetch('/api/generate_pdf', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(currentViewState)
    })
    .then(response => {
        if (response.ok) {
            return response.blob();
        } else {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
    })
    .then(blob => {
        // Create download link for the PDF
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        
        // Generate filename based on current view state
        const actualBucketCount = currentViewState.current_chart_data ? 
            currentViewState.current_chart_data.bucket_ids.length : 0;
        const filename = `faq_bucket_report_${actualBucketCount}_buckets.pdf`;
        
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
        
        showMessage('PDF report generated successfully!', 'success');
    })
    .catch(error => {
        console.error('Error generating PDF:', error);
        showMessage('Error generating PDF: ' + error.message, 'error');
    })
    .finally(() => {
        // Restore button state
        btn.innerHTML = originalText;
        btn.disabled = false;
    });
}

function showLoading(show) {
    console.log('showLoading called with:', show);
    document.getElementById('loadingIndicator').style.display = show ? 'block' : 'none';
    document.getElementById('dashboardContent').style.display = show ? 'none' : 'block';
    
    const loadingElements = document.querySelectorAll('.loading');
    loadingElements.forEach(el => {
        el.style.display = show ? 'inline-block' : 'none';
    });
    
    // Debug: check if dashboard content is visible
    if (!show) {
        console.log('Dashboard content should be visible now');
        console.log('Dashboard content element:', document.getElementById('dashboardContent'));
        console.log('Dashboard content display style:', document.getElementById('dashboardContent').style.display);
    }
}

function showMessage(message, type) {
    const messageDiv = document.getElementById('directoryMessage');
    messageDiv.textContent = message;
    messageDiv.className = ''; // Clear previous classes
    if (type === 'success') {
        messageDiv.className = 'success-message';
    } else if (type === 'warning') {
        messageDiv.className = 'warning-message';
    } else if (type === 'error') {
        messageDiv.className = 'error-message';
    } else if (type === 'info') {
        messageDiv.className = 'info-message';
    }
    
    setTimeout(() => {
        messageDiv.textContent = '';
        messageDiv.className = '';
    }, 5000);
}

function formatCanonicalAnswer(answer) {
    if (!answer) return '';
    
    let formatted = answer;
    
    // ========================================
    // TEXT FORMATTING RULES
    // ========================================
    
    // 1. Bold text: **text** -> <strong>text</strong>
    formatted = formatted.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    
    // 2. Italic text: *text* -> <em>text</em> (but not bullet points)
    // Look for *text* where text doesn't start with spaces (bullet points start with "   ")
    formatted = formatted.replace(/\*([^*\s][^*]*[^*\s])\*/g, '<em>$1</em>');
    formatted = formatted.replace(/\*([^*\s][^*]*)\*/g, '<em>$1</em>');
    formatted = formatted.replace(/\*([^*]*[^*\s])\*/g, '<em>$1</em>');
    
    // 3. Code blocks: `text` -> <code>text</code>
    formatted = formatted.replace(/`([^`]+)`/g, '<code>$1</code>');
    
    // ========================================
    // LIST FORMATTING RULES
    // ========================================
    
    // 4. Bullet points: *   Item -> <br><span class="list-indent"></span>• Item
    // Look for asterisk followed by exactly 3 spaces
    formatted = formatted.replace(/\*   /g, '<br><span class="list-indent"></span>• ');
    
    // 5. Ordered lists: Convert numbered lists to proper HTML structure
    // Look for patterns like "1. Text 2. Text 3. Text" (no spaces after period)
    if (/\d+\.\s/.test(formatted)) {
        formatted = formatOrderedLists(formatted);
    }
    
    // 6. Remaining bullet points: * Item -> <br><span class="list-indent"></span>• Item
    // But only if they're not already handled and not part of italic text
    formatted = formatted.replace(/(?<!<em>)\* (?![^<]*<\/em>)/g, '<br><span class="list-indent"></span>• ');
    
    return formatted;
}

function formatOrderedLists(text) {
    // Split into paragraphs to find list sections
    const paragraphs = text.split(/\n+/);
    let result = [];
    
    for (let i = 0; i < paragraphs.length; i++) {
        const para = paragraphs[i];
        
        // Check if this paragraph contains a numbered list pattern
        if (/\d+\.\s/.test(para)) {
            // Find where the numbered list actually starts
            const listStartMatch = para.match(/(.*?)(\d+\.\s+.*)/);
            
            if (listStartMatch) {
                const introText = listStartMatch[1]; // Text before the list
                const listText = listStartMatch[2];  // The numbered list portion
                
                // Add the introductory text first
                if (introText.trim()) {
                    result.push(introText.trim());
                }
                
                // Now process just the numbered list portion
                const listParts = listText.split(/(\d+\.\s+)/);
                let listItems = [];
                
                for (let j = 0; j < listParts.length; j++) {
                    const part = listParts[j];
                    
                    if (/^\d+\.\s+$/.test(part)) {
                        // This is a number + period + spaces, start collecting text
                        let currentText = '';
                        j++; // Move to next part (the text)
                        if (j < listParts.length) {
                            currentText = listParts[j];
                            listItems.push(`<br><span class="list-indent"></span>${part}${currentText.trim()}`);
                        }
                    }
                }
                
                // If we found list items, add them to result
                if (listItems.length > 0) {
                    result.push(listItems.join(''));
                }
            } else {
                // Fallback: no clear intro text, process the whole paragraph
                result.push(para);
            }
        } else {
            result.push(para);
        }
    }
    
    return result.join('<br>');
}
