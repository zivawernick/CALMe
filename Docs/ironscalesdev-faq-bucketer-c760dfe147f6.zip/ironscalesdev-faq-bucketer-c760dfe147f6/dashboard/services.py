#!/usr/bin/env python3
"""
Business logic services for the FAQ Bucket Dashboard.
"""

import os
import logging
import tempfile
from typing import Dict, Any, Optional, List
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
import pandas as pd

logger: logging.Logger = logging.getLogger(__name__)

class PDFReportService:
    """Service for generating PDF reports from bucket data."""
    
    def __init__(self) -> None:
        self.styles = getSampleStyleSheet()
    
    def generate_pdf_report(self, directory_path: str, bucket_count: int, output_stream: Any, 
                           current_page: int = 1, total_pages: int = 1, 
                           similarity_filters: Optional[Dict[str, Any]] = None, 
                           search_term: str = '', chart_bucket_count: int = 20, 
                           current_chart_data: Optional[Dict[str, Any]] = None, 
                           chart_image: str = '') -> None:
        """
        Generate a PDF report for the specified number of largest buckets based on current view state.
        
        Args:
            directory_path: Path to directory containing bucket data
            bucket_count: Number of buckets to include in report
            output_stream: Stream to write PDF to
            current_page: Current page number being viewed
            total_pages: Total number of pages
            similarity_filters: Active similarity filters
            search_term: Current search term
            chart_bucket_count: Number of buckets shown in chart
            current_chart_data: Current chart data state
            chart_image: Base64 encoded chart image
        """
        temp_image_path: Optional[str] = None
        
        try:
            logger.info(f"Generating PDF report for directory: {directory_path}")
            
            # Load all required data using utility functions
            from utils import load_csv_safely
            
            summary_path: str = os.path.join(directory_path, 'faq_bucket_summary.csv')
            canonical_path: str = os.path.join(directory_path, 'faq_bucket_canonical_qna.csv')
            assignments_path: str = os.path.join(directory_path, 'faq_bucket_assignments.csv')
            
            summary_df: pd.DataFrame = load_csv_safely(summary_path)
            canonical_df: pd.DataFrame = load_csv_safely(canonical_path)
            assignments_df: pd.DataFrame = load_csv_safely(assignments_path)
            
            # Create PDF
            doc: SimpleDocTemplate = SimpleDocTemplate(output_stream, pagesize=A4)
            story: List[Any] = []
            
            # Add title
            story.extend(self._create_title_section())
            
            # Add chart image if available
            temp_image_path = self._add_chart_image(story, chart_image)
            
            # Add view state summary
            story.extend(self._create_view_state_section(
                directory_path, summary_df, current_page, total_pages,
                similarity_filters, search_term, chart_bucket_count, chart_image
            ))
            
            # Add bucket details
            story.extend(self._create_bucket_details_section(
                summary_df, canonical_df, assignments_df, current_chart_data
            ))
            
            # Build the PDF
            doc.build(story)
            logger.info("PDF report generated successfully")
            
        except Exception as e:
            logger.error(f"Error generating PDF report: {e}")
            raise Exception(f"Error generating PDF: {str(e)}")
        finally:
            # Clean up temporary image file
            self._cleanup_temp_image(temp_image_path)
    
    def _create_title_section(self) -> List[Any]:
        """Create the title section of the PDF."""
        story: List[Any] = []
        
        title_style: ParagraphStyle = ParagraphStyle(
            'CustomTitle',
            parent=self.styles['Heading1'],
            fontSize=24,
            spaceAfter=30,
            alignment=1  # Center
        )
        
        story.append(Paragraph("FAQ Bucket Analysis Report", title_style))
        story.append(Spacer(1, 20))
        
        return story
    
    def _add_chart_image(self, story: List[Any], chart_image: str) -> Optional[str]:
        """Add chart image to PDF if available."""
        if not chart_image or not chart_image.startswith('data:image/'):
            return None
            
        try:
            # Extract base64 data from data URL
            import base64
            image_data: str = chart_image.split(',')[1]
            image_bytes: bytes = base64.b64decode(image_data)
            
            # Create temporary file for the image
            with tempfile.NamedTemporaryFile(suffix='.png', delete=False) as img_file:
                img_file.write(image_bytes)
                temp_image_path: str = img_file.name
            
            # Add image to PDF with appropriate sizing
            img: Image = Image(temp_image_path, width=6*inch, height=4*inch)
            story.append(img)
            
            # Add caption for the chart
            caption_style: ParagraphStyle = ParagraphStyle(
                'Caption',
                parent=self.styles['Normal'],
                fontSize=10,
                alignment=1,  # Center
                spaceAfter=20,
                textColor=colors.grey
            )
            story.append(Paragraph("Current Chart View - Buckets by Size and Similarity", caption_style))
            story.append(Spacer(1, 20))
            
            logger.info("Chart image added to PDF successfully")
            return temp_image_path
            
        except Exception as e:
            logger.warning(f"Could not add chart image to PDF: {e}")
            return None
    
    def _create_view_state_section(self, directory_path: str, summary_df: pd.DataFrame,
                                 current_page: int, total_pages: int,
                                 similarity_filters: Optional[Dict[str, Any]], search_term: str,
                                 chart_bucket_count: int, chart_image: str) -> List[Any]:
        """Create the view state summary section."""
        story: List[Any] = []
        
        story.append(Paragraph("Current View State", self.styles['Heading2']))
        story.append(Paragraph(f"Directory: {directory_path}", self.styles['Normal']))
        story.append(Paragraph(f"Total Buckets: {len(summary_df)}", self.styles['Normal']))
        story.append(Paragraph(f"Total Questions: {summary_df['n_items'].sum()}", self.styles['Normal']))
        
        # Add view state information
        if similarity_filters:
            active_filters: List[str] = [f"{range_name}" for range_name, is_active in similarity_filters.items() if is_active]
            if active_filters:
                story.append(Paragraph(f"Active Similarity Filters: {', '.join(active_filters)}", self.styles['Normal']))
            else:
                story.append(Paragraph("Similarity Filters: All ranges hidden", self.styles['Normal']))
        
        if search_term:
            story.append(Paragraph(f"Search Filter: '{search_term}'", self.styles['Normal']))
        
        if total_pages > 1:
            story.append(Paragraph(f"Current Page: {current_page} of {total_pages}", self.styles['Normal']))
            story.append(Paragraph(f"Buckets per Page: {chart_bucket_count}", self.styles['Normal']))
        
        if chart_image and chart_image.startswith('data:image/'):
            story.append(Paragraph("Chart Image: Included above", self.styles['Normal']))
        
        story.append(Spacer(1, 20))
        
        return story
    
    def _create_bucket_details_section(self, summary_df: pd.DataFrame, 
                                     canonical_df: pd.DataFrame, 
                                     assignments_df: pd.DataFrame,
                                     current_chart_data: Optional[Dict[str, Any]]) -> List[Any]:
        """Create the bucket details section."""
        story: List[Any] = []
        
        if current_chart_data and current_chart_data.get('bucket_ids'):
            # Use the buckets currently displayed on the chart
            bucket_ids_to_report: List[int] = current_chart_data['bucket_ids']
            story.append(Paragraph(f"Report Contents: {len(bucket_ids_to_report)} buckets currently displayed", self.styles['Heading3']))
            story.append(Spacer(1, 10))
            
            # Get bucket details for currently displayed buckets
            for bucket_id in bucket_ids_to_report:
                story.extend(self._create_single_bucket_section(
                    bucket_id, summary_df, canonical_df, assignments_df
                ))
        else:
            # Fallback to original behavior if no chart data
            story.append(Paragraph("Report Contents: Top buckets by size (fallback mode)", self.styles['Heading3']))
            story.append(Spacer(1, 10))
            
            # Get top N buckets by size
            top_buckets: pd.DataFrame = summary_df.head(10)  # Default to top 10
            
            # Bucket details
            for idx, bucket in top_buckets.iterrows():
                story.extend(self._create_single_bucket_section(
                    bucket['bucket_id'], summary_df, canonical_df, assignments_df
                ))
        
        return story
    
    def _create_single_bucket_section(self, bucket_id: int, summary_df: pd.DataFrame,
                                    canonical_df: pd.DataFrame, 
                                    assignments_df: pd.DataFrame) -> List[Any]:
        """Create details for a single bucket."""
        story: List[Any] = []
        
        bucket_row: pd.DataFrame = summary_df[summary_df['bucket_id'] == bucket_id]
        if len(bucket_row) == 0:
            return story
            
        bucket: pd.Series = bucket_row.iloc[0]
        story.append(Paragraph(f"Bucket {bucket['bucket_id']}: {bucket['bucket_label']}", self.styles['Heading3']))
        story.append(Paragraph(f"Number of Questions: {bucket['n_items']}", self.styles['Normal']))
        story.append(Paragraph(f"Median Similarity: {bucket['median_similarity']:.4f}", self.styles['Normal']))
        story.append(Spacer(1, 10))
        
        # Get questions for this bucket
        bucket_questions: pd.DataFrame = assignments_df[assignments_df['bucket_id'] == bucket['bucket_id']]
        
        if len(bucket_questions) > 0:
            # Most extreme questions (first and last by index)
            first_question: str = bucket_questions.iloc[0]['question_text']
            last_question: str = bucket_questions.iloc[-1]['question_text']
            
            # Median question (middle question)
            median_idx: int = len(bucket_questions) // 2
            median_question: str = bucket_questions.iloc[median_idx]['question_text']
            
            # Canonical answer
            canonical_row: pd.DataFrame = canonical_df[canonical_df['bucket_id'] == bucket['bucket_id']]
            canonical_answer: str = canonical_row.iloc[0]['canonical_answer'] if len(canonical_row) > 0 else "Not available"
            
            story.append(Paragraph("Sample Questions:", self.styles['Heading4']))
            story.append(Paragraph(f"• First: {first_question[:200]}{'...' if len(first_question) > 200 else ''}", self.styles['Normal']))
            story.append(Paragraph(f"• Median: {median_question[:200]}{'...' if len(median_question) > 200 else ''}", self.styles['Normal']))
            story.append(Paragraph(f"• Last: {last_question[:200]}{'...' if len(last_question) > 200 else ''}", self.styles['Normal']))
            story.append(Spacer(1, 10))
            
            story.append(Paragraph("Canonical Answer:", self.styles['Heading4']))
            story.append(Paragraph(canonical_answer[:500] + ('...' if len(canonical_answer) > 500 else ''), self.styles['Normal']))
        
        story.append(Spacer(1, 20))
        return story
    
    def _cleanup_temp_image(self, temp_image_path: Optional[str]) -> None:
        """Clean up temporary image file."""
        from utils import cleanup_temp_files
        if temp_image_path:
            cleanup_temp_files([temp_image_path])

class DataProcessingService:
    """Service for processing and preparing data for the dashboard."""
    
    @staticmethod
    def prepare_chart_data(summary_df: pd.DataFrame) -> Dict[str, Any]:
        """Prepare summary data for charts."""
        try:
            from utils import prepare_chart_data as utils_prepare_chart_data
            
            # Use utility function for chart data preparation
            chart_data: Dict[str, Any] = utils_prepare_chart_data(summary_df)
            
            # Add additional fields specific to this service
            chart_data.update({
                'similarities': summary_df['median_similarity'].tolist(),
                'example_questions': summary_df['example_question'].tolist(),
                'bucket_ids': summary_df['bucket_id'].tolist()
            })
            
            logger.info(f"Chart data prepared for {len(summary_df)} buckets")
            return chart_data
            
        except Exception as e:
            logger.error(f"Error preparing chart data: {e}")
            raise Exception(f"Error preparing chart data: {str(e)}")
    
    @staticmethod
    def prepare_summary_records(summary_df: pd.DataFrame) -> List[Dict[str, Any]]:
        """Convert summary DataFrame to records with proper type conversion."""
        try:
            from utils import convert_numpy_types, clean_dataframe
            
            # Clean the DataFrame first
            cleaned_df: pd.DataFrame = clean_dataframe(summary_df)
            
            # Convert to records with proper type conversion
            summary_records: List[Dict[str, Any]] = []
            for record in cleaned_df.to_dict('records'):
                converted_record: Dict[str, Any] = convert_numpy_types(record)
                summary_records.append(converted_record)
            
            logger.info(f"Summary records prepared: {len(summary_records)} buckets")
            return summary_records
            
        except Exception as e:
            logger.error(f"Error preparing summary records: {e}")
            raise Exception(f"Error preparing summary records: {str(e)}")
