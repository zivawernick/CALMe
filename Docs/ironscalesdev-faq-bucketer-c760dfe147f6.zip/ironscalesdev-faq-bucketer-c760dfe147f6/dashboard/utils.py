#!/usr/bin/env python3
"""
Utility functions and validation logic for the FAQ Bucket Dashboard.
"""

import os
import logging
import tempfile
import base64
from pathlib import Path
from typing import Tuple, Dict, Any, Optional, List, Union
import pandas as pd
from config import config

# Configure logging based on config
logging.basicConfig(
    level=getattr(logging, config.LOG_LEVEL),
    format=config.LOG_FORMAT
)
logger = logging.getLogger(__name__)

# ============================================================================
# File and Path Utilities
# ============================================================================

def sanitize_path(path: str) -> str:
    """
    Sanitize and validate file paths to prevent directory traversal attacks.
    
    Args:
        path: Input path string
        
    Returns:
        Sanitized path string
        
    Raises:
        ValueError: If path contains suspicious patterns
    """
    if not path or not isinstance(path, str):
        raise ValueError("Path must be a non-empty string")
    
    # Normalize path and resolve to absolute path
    try:
        resolved_path = Path(path).resolve()
    except Exception as e:
        raise ValueError(f"Invalid path format: {e}")
    
    # Check for suspicious patterns
    suspicious_patterns = ['..', '~', '*', '?', '|', '<', '>', '"']
    path_str = str(resolved_path)
    
    for pattern in suspicious_patterns:
        if pattern in path_str:
            raise ValueError(f"Path contains suspicious pattern: {pattern}")
    
    # Ensure path is within reasonable bounds (not too deep)
    if len(resolved_path.parts) > 20:
        raise ValueError("Path is too deep (more than 20 levels)")
    
    return str(resolved_path)

def ensure_directory_exists(directory_path: str) -> str:
    """
    Ensure a directory exists, creating it if necessary.
    
    Args:
        directory_path: Path to directory
        
    Returns:
        Path to the directory (created if it didn't exist)
    """
    try:
        sanitized_path = sanitize_path(directory_path)
        os.makedirs(sanitized_path, exist_ok=True)
        logger.info(f"Directory ensured: {sanitized_path}")
        return sanitized_path
    except Exception as e:
        logger.error(f"Error ensuring directory exists: {e}")
        raise Exception(f"Could not create directory: {str(e)}")

def get_file_extension(file_path: str) -> str:
    """
    Get the file extension from a file path.
    
    Args:
        file_path: Path to the file
        
    Returns:
        File extension (lowercase, without the dot)
    """
    return Path(file_path).suffix.lower().lstrip('.')

def is_valid_csv_file(file_path: str) -> bool:
    """
    Check if a file is a valid CSV file.
    
    Args:
        file_path: Path to the file
        
    Returns:
        True if file is a valid CSV, False otherwise
    """
    if not os.path.exists(file_path):
        return False
    
    extension = get_file_extension(file_path)
    return extension == 'csv'

# ============================================================================
# CSV File Operations
# ============================================================================

def load_csv_safely(file_path: str, encoding: str = 'utf-8', **kwargs) -> pd.DataFrame:
    """
    Safely load a CSV file with error handling and validation.
    
    Args:
        file_path: Path to the CSV file
        encoding: File encoding (default: utf-8)
        **kwargs: Additional arguments to pass to pd.read_csv
        
    Returns:
        Loaded DataFrame
        
    Raises:
        Exception: If file cannot be loaded
    """
    try:
        # Validate file path
        sanitized_path = sanitize_path(file_path)
        
        if not os.path.exists(sanitized_path):
            raise Exception(f"File does not exist: {sanitized_path}")
        
        if not is_valid_csv_file(sanitized_path):
            raise Exception(f"File is not a valid CSV: {sanitized_path}")
        
        # Load CSV with error handling
        df = pd.read_csv(sanitized_path, encoding=encoding, **kwargs)
        
        if df.empty:
            logger.warning(f"CSV file is empty: {sanitized_path}")
        
        logger.info(f"Successfully loaded CSV: {sanitized_path} ({len(df)} rows)")
        return df
        
    except Exception as e:
        logger.error(f"Error loading CSV file {file_path}: {e}")
        raise Exception(f"Failed to load CSV file: {str(e)}")

def save_csv_safely(df: pd.DataFrame, file_path: str, encoding: str = 'utf-8', **kwargs) -> str:
    """
    Safely save a DataFrame to CSV with error handling.
    
    Args:
        df: DataFrame to save
        file_path: Path where to save the CSV
        encoding: File encoding (default: utf-8)
        **kwargs: Additional arguments to pass to df.to_csv
        
    Returns:
        Path to the saved file
        
    Raises:
        Exception: If file cannot be saved
    """
    try:
        # Ensure directory exists
        directory = os.path.dirname(file_path)
        if directory:
            ensure_directory_exists(directory)
        
        # Save CSV
        df.to_csv(file_path, encoding=encoding, index=False, **kwargs)
        
        logger.info(f"Successfully saved CSV: {file_path} ({len(df)} rows)")
        return file_path
        
    except Exception as e:
        logger.error(f"Error saving CSV file {file_path}: {e}")
        raise Exception(f"Failed to save CSV file: {str(e)}")

# ============================================================================
# Data Validation and Processing
# ============================================================================

def validate_directory(directory_path: str) -> Tuple[bool, str]:
    """
    Validate that a directory contains all required files.
    
    Args:
        directory_path: Path to directory to validate
        
    Returns:
        Tuple of (is_valid, message)
    """
    try:
        # Sanitize the path first
        sanitized_path = sanitize_path(directory_path)
        
        if not os.path.isdir(sanitized_path):
            return False, "Directory does not exist"
        
        missing_files = []
        for file in config.REQUIRED_FILES:
            file_path = os.path.join(sanitized_path, file)
            if not os.path.exists(file_path):
                missing_files.append(file)
        
        if missing_files:
            return False, f"Missing required files: {', '.join(missing_files)}"
        
        logger.info(f"Directory validated successfully: {sanitized_path}")
        return True, "Directory is valid"
        
    except ValueError as e:
        logger.warning(f"Path validation failed: {e}")
        return False, f"Invalid path: {str(e)}"
    except Exception as e:
        logger.error(f"Unexpected error during directory validation: {e}")
        return False, f"Validation error: {str(e)}"

def validate_dataframe(df: pd.DataFrame, required_columns: List[str], name: str = "DataFrame") -> bool:
    """
    Validate that a DataFrame has required columns.
    
    Args:
        df: DataFrame to validate
        required_columns: List of required column names
        name: Name of the DataFrame for logging
        
    Returns:
        True if validation passes
        
    Raises:
        ValueError: If validation fails
    """
    if df is None or df.empty:
        raise ValueError(f"{name} is None or empty")
    
    missing_columns = [col for col in required_columns if col not in df.columns]
    if missing_columns:
        raise ValueError(f"{name} missing required columns: {missing_columns}")
    
    logger.debug(f"{name} validation passed: {len(df)} rows, {len(df.columns)} columns")
    return True

def clean_dataframe(df: pd.DataFrame, remove_duplicates: bool = True, 
                   fill_na: bool = True, **kwargs) -> pd.DataFrame:
    """
    Clean a DataFrame by removing duplicates, filling NA values, etc.
    
    Args:
        df: DataFrame to clean
        remove_duplicates: Whether to remove duplicate rows
        fill_na: Whether to fill NA values
        **kwargs: Additional cleaning options
        
    Returns:
        Cleaned DataFrame
    """
    try:
        cleaned_df = df.copy()
        
        if remove_duplicates:
            initial_rows = len(cleaned_df)
            cleaned_df = cleaned_df.drop_duplicates()
            if len(cleaned_df) < initial_rows:
                logger.info(f"Removed {initial_rows - len(cleaned_df)} duplicate rows")
        
        if fill_na:
            # Fill numeric columns with 0, string columns with empty string
            for col in cleaned_df.columns:
                if cleaned_df[col].dtype in ['int64', 'float64']:
                    cleaned_df[col] = cleaned_df[col].fillna(0)
                else:
                    cleaned_df[col] = cleaned_df[col].fillna('')
        
        logger.debug(f"DataFrame cleaned: {len(cleaned_df)} rows")
        return cleaned_df
        
    except Exception as e:
        logger.error(f"Error cleaning DataFrame: {e}")
        return df  # Return original if cleaning fails

# ============================================================================
# API Response Utilities
# ============================================================================

def create_api_response(success: bool, data: Any = None, 
                       error: str = None, status_code: int = 200) -> Tuple[Dict, int]:
    """
    Create a standardized API response.
    
    Args:
        success: Whether the operation was successful
        data: Response data (if successful)
        error: Error message (if not successful)
        status_code: HTTP status code
        
    Returns:
        Tuple of (response_dict, status_code)
    """
    response = {
        'success': success,
        'timestamp': pd.Timestamp.now().isoformat()
    }
    
    if success and data is not None:
        response['data'] = data
    elif not success and error:
        response['error'] = error
    
    return response, status_code

def create_success_response(data: Any = None, message: str = None) -> Tuple[Dict, int]:
    """
    Create a success API response.
    
    Args:
        data: Response data
        message: Optional success message
        
    Returns:
        Tuple of (response_dict, status_code)
    """
    if data is not None and message is None:
        # If only data is provided, return it directly with success flag
        response = {
            'success': True,
            'timestamp': pd.Timestamp.now().isoformat()
        }
        response.update(data)
    else:
        # If message is provided, wrap data in 'data' field
        response = {
            'success': True,
            'timestamp': pd.Timestamp.now().isoformat()
        }
        
        if data is not None:
            response['data'] = data
        if message:
            response['message'] = message
    
    return response, 200

def create_error_response(error: str, status_code: int = 500, 
                        details: str = None) -> Tuple[Dict, int]:
    """
    Create an error API response.
    
    Args:
        error: Error message
        status_code: HTTP status code
        details: Optional error details
        
    Returns:
        Tuple of (response_dict, status_code)
    """
    response = {
        'success': False,
        'error': error,
        'timestamp': pd.Timestamp.now().isoformat()
    }
    
    if details:
        response['details'] = details
    
    return response, status_code

# ============================================================================
# Chart Data Utilities
# ============================================================================

def prepare_chart_data(df: pd.DataFrame, max_items: int = None) -> Dict[str, Any]:
    """
    Prepare data for chart visualization.
    
    Args:
        df: DataFrame containing chart data
        max_items: Maximum number of items to include
        
    Returns:
        Dictionary with chart-ready data
    """
    try:
        if df is None or df.empty:
            return {'labels': [], 'data': [], 'colors': []}
        
        # Limit items if specified
        if max_items and len(df) > max_items:
            df = df.head(max_items)
        
        # Extract chart data
        labels = df.get('bucket_label', df.index).astype(str).tolist()
        data = df.get('n_items', [0] * len(df)).tolist()
        
        # Generate colors if not present
        colors = generate_chart_colors(len(labels))
        
        return {
            'labels': labels,
            'sizes': data,  # Frontend expects 'sizes' not 'data'
            'colors': colors,
            'total_items': sum(data)
        }
        
    except Exception as e:
        logger.error(f"Error preparing chart data: {e}")
        return {'labels': [], 'data': [], 'colors': [], 'error': str(e)}

def generate_chart_colors(count: int) -> List[str]:
    """
    Generate a list of colors for charts.
    
    Args:
        count: Number of colors needed
        
    Returns:
        List of color strings
    """
    # Predefined color palette
    base_colors = [
        'rgba(255, 99, 132, 0.8)',   # Red
        'rgba(54, 162, 235, 0.8)',   # Blue
        'rgba(255, 205, 86, 0.8)',   # Yellow
        'rgba(75, 192, 192, 0.8)',   # Green
        'rgba(153, 102, 255, 0.8)',  # Purple
        'rgba(255, 159, 64, 0.8)',   # Orange
        'rgba(199, 199, 199, 0.8)',  # Gray
        'rgba(83, 102, 255, 0.8)',   # Indigo
    ]
    
    colors = []
    for i in range(count):
        colors.append(base_colors[i % len(base_colors)])
    
    return colors

# ============================================================================
# File and Image Utilities
# ============================================================================

def create_temp_file(suffix: str = '.tmp', delete_on_close: bool = True) -> str:
    """
    Create a temporary file and return its path.
    
    Args:
        suffix: File extension suffix
        delete_on_close: Whether to delete file when closed
        
    Returns:
        Path to the temporary file
    """
    try:
        temp_file = tempfile.NamedTemporaryFile(
            suffix=suffix, 
            delete=delete_on_close
        )
        temp_path = temp_file.name
        temp_file.close()
        
        logger.debug(f"Created temporary file: {temp_path}")
        return temp_path
        
    except Exception as e:
        logger.error(f"Error creating temporary file: {e}")
        raise Exception(f"Could not create temporary file: {str(e)}")

def save_base64_image(base64_data: str, output_path: str) -> str:
    """
    Save a base64 encoded image to a file.
    
    Args:
        base64_data: Base64 encoded image data
        output_path: Path where to save the image
        
    Returns:
        Path to the saved image
        
    Raises:
        Exception: If image cannot be saved
    """
    try:
        # Ensure directory exists
        directory = os.path.dirname(output_path)
        if directory:
            ensure_directory_exists(directory)
        
        # Decode and save image
        if base64_data.startswith('data:image/'):
            # Remove data URL prefix
            image_data = base64_data.split(',')[1]
        else:
            image_data = base64_data
        
        image_bytes = base64.b64decode(image_data)
        
        with open(output_path, 'wb') as f:
            f.write(image_bytes)
        
        logger.info(f"Saved base64 image to: {output_path}")
        return output_path
        
    except Exception as e:
        logger.error(f"Error saving base64 image: {e}")
        raise Exception(f"Could not save image: {str(e)}")

def cleanup_temp_files(file_paths: List[str]) -> None:
    """
    Clean up temporary files.
    
    Args:
        file_paths: List of file paths to remove
    """
    for file_path in file_paths:
        try:
            if file_path and os.path.exists(file_path):
                os.remove(file_path)
                logger.debug(f"Cleaned up temporary file: {file_path}")
        except Exception as e:
            logger.warning(f"Could not clean up temporary file {file_path}: {e}")

# ============================================================================
# Data Processing Utilities
# ============================================================================

def load_bucket_data(directory_path: str) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Load and process bucket data from the specified directory.
    
    Args:
        directory_path: Path to directory containing bucket data files
        
    Returns:
        Tuple of (merged_summary_df, assignments_df)
        
    Raises:
        Exception: If data loading fails
    """
    try:
        # Validate directory first
        is_valid, message = validate_directory(directory_path)
        if not is_valid:
            raise Exception(f"Directory validation failed: {message}")
        
        logger.info(f"Loading bucket data from: {directory_path}")
        
        # Load summary data
        summary_path = os.path.join(directory_path, 'faq_bucket_summary.csv')
        summary_df = load_csv_safely(summary_path)
        logger.info(f"Loaded summary data: {len(summary_df)} buckets")
        
        # Load canonical Q&A data
        canonical_path = os.path.join(directory_path, 'faq_bucket_canonical_qna.csv')
        canonical_df = load_csv_safely(canonical_path)
        logger.info(f"Loaded canonical Q&A data: {len(canonical_df)} entries")
        
        # Load assignments data
        assignments_path = os.path.join(directory_path, 'faq_bucket_assignments.csv')
        assignments_df = load_csv_safely(assignments_path)
        logger.info(f"Loaded assignments data: {len(assignments_df)} assignments")
        
        # Validate required columns
        validate_dataframe(summary_df, ['bucket_id', 'bucket_label', 'n_items'], 'Summary DataFrame')
        validate_dataframe(canonical_df, ['bucket_id', 'bucket_label'], 'Canonical DataFrame')
        validate_dataframe(assignments_df, ['bucket_id', 'question_text'], 'Assignments DataFrame')
        
        # Clean data
        summary_df = clean_dataframe(summary_df)
        canonical_df = clean_dataframe(canonical_df)
        assignments_df = clean_dataframe(assignments_df)
        
        # Merge data
        merged_df = summary_df.merge(canonical_df, on=['bucket_id', 'bucket_label'], how='left')
        
        # Sort by number of items (descending)
        merged_df = merged_df.sort_values('n_items', ascending=False)
        
        logger.info(f"Successfully loaded and merged bucket data")
        return merged_df, assignments_df
        
    except Exception as e:
        logger.error(f"Error loading bucket data: {e}")
        raise Exception(f"Error loading data: {str(e)}")

def get_bucket_questions(bucket_id: int, assignments_df: pd.DataFrame, 
                        page: int = 1, page_size: int = None) -> Dict[str, Any]:
    """
    Get questions for a specific bucket with pagination.
    
    Args:
        bucket_id: ID of the bucket to get questions for
        assignments_df: DataFrame containing bucket assignments
        page: Page number (1-based)
        page_size: Number of questions per page (uses config default if None)
        
    Returns:
        Dictionary containing paginated questions and metadata
    """
    try:
        # Use config default if page_size not specified
        if page_size is None:
            page_size = config.DEFAULT_PAGE_SIZE
            
        # Validate inputs
        if page < 1:
            page = 1
        if page_size < 1 or page_size > config.MAX_PAGE_SIZE:
            page_size = config.DEFAULT_PAGE_SIZE
            
        bucket_questions = assignments_df[assignments_df['bucket_id'] == bucket_id]
        
        total_questions = len(bucket_questions)
        start_idx = (page - 1) * page_size
        end_idx = start_idx + page_size
        
        paginated_questions = bucket_questions.iloc[start_idx:end_idx]
        
        logger.info(f"Retrieved {len(paginated_questions)} questions for bucket {bucket_id} (page {page})")
        
        return {
            'questions': paginated_questions.to_dict('records'),
            'total': total_questions,
            'page': page,
            'page_size': page_size,
            'total_pages': (total_questions + page_size - 1) // page_size
        }
        
    except Exception as e:
        logger.error(f"Error getting bucket questions: {e}")
        raise Exception(f"Error retrieving bucket questions: {str(e)}")

def convert_numpy_types(data: Any) -> Any:
    """
    Convert numpy types to Python native types for JSON serialization.
    
    Args:
        data: Data that may contain numpy types
        
    Returns:
        Data with numpy types converted to Python native types
    """
    if hasattr(data, 'item'):  # numpy scalar
        return data.item()
    elif isinstance(data, dict):
        return {key: convert_numpy_types(value) for key, value in data.items()}
    elif isinstance(data, list):
        return [convert_numpy_types(item) for item in data]
    else:
        return data

def paginate_dataframe(df: pd.DataFrame, page: int = 1, 
                      page_size: int = None) -> Dict[str, Any]:
    """
    Paginate a DataFrame with validation and error handling.
    
    Args:
        df: DataFrame to paginate
        page: Page number (1-based)
        page_size: Number of items per page
        
    Returns:
        Dictionary with paginated data and metadata
    """
    try:
        if df is None or df.empty:
            return {
                'data': [],
                'total': 0,
                'page': 1,
                'page_size': page_size or config.DEFAULT_PAGE_SIZE,
                'total_pages': 0
            }
        
        # Use config default if page_size not specified
        if page_size is None:
            page_size = config.DEFAULT_PAGE_SIZE
        
        # Validate inputs
        if page < 1:
            page = 1
        if page_size < 1 or page_size > config.MAX_PAGE_SIZE:
            page_size = config.DEFAULT_PAGE_SIZE
        
        total_items = len(df)
        start_idx = (page - 1) * page_size
        end_idx = start_idx + page_size
        
        # Ensure indices are within bounds
        start_idx = max(0, min(start_idx, total_items))
        end_idx = max(start_idx, min(end_idx, total_items))
        
        paginated_data = df.iloc[start_idx:end_idx]
        
        return {
            'data': paginated_data.to_dict('records'),
            'total': total_items,
            'page': page,
            'page_size': page_size,
            'total_pages': (total_items + page_size - 1) // page_size
        }
        
    except Exception as e:
        logger.error(f"Error paginating DataFrame: {e}")
        raise Exception(f"Error paginating data: {str(e)}")
