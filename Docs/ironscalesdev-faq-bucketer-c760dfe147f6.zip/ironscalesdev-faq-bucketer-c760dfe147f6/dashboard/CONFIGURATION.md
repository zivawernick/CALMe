# Dashboard Configuration Guide

The FAQ Bucket Dashboard now supports flexible configuration through environment variables, making it easy to deploy in different environments.

## Quick Start

1. **Copy the example configuration:**
   ```bash
   cp env.example .env
   ```

2. **Edit the .env file** with your desired settings

3. **Run the dashboard** - it will automatically use your configuration

## Environment Variables

### Basic Configuration

| Variable | Default | Description |
|----------|---------|-------------|
| `DASHBOARD_ENV` | `development` | Environment: `development` or `production` |
| `DASHBOARD_HOST` | `0.0.0.0` | Host to bind to (use `127.0.0.1` for local-only) |
| `DASHBOARD_PORT` | `5000` | Port to run on |
| `DASHBOARD_DEBUG` | `false` | Enable debug mode |

### Security

| Variable | Default | Description |
|----------|---------|-------------|
| `DASHBOARD_SECRET_KEY` | `dev-secret-key-change-in-production` | Flask secret key (MUST change in production) |
| `DASHBOARD_ALLOWED_HOSTS` | `*` | Comma-separated list of allowed hosts |

### File Upload

| Variable | Default | Description |
|----------|---------|-------------|
| `DASHBOARD_MAX_FILE_SIZE_MB` | `16` | Maximum file upload size in MB |

### Chart Settings

| Variable | Default | Description |
|----------|---------|-------------|
| `DASHBOARD_DEFAULT_BUCKET_COUNT` | `25` | Default number of buckets to show in charts |
| `DASHBOARD_MAX_BUCKET_COUNT` | `100` | Maximum buckets that can be displayed |
| `DASHBOARD_CHART_HEIGHT` | `400` | Chart height in pixels |

### Pagination

| Variable | Default | Description |
|----------|---------|-------------|
| `DASHBOARD_DEFAULT_PAGE_SIZE` | `20` | Default questions per page in bucket details |
| `DASHBOARD_MAX_PAGE_SIZE` | `100` | Maximum questions per page |

### Logging

| Variable | Default | Description |
|----------|---------|-------------|
| `DASHBOARD_LOG_LEVEL` | `INFO` | Log level: `DEBUG`, `INFO`, `WARNING`, `ERROR` |
| `DASHBOARD_LOG_FORMAT` | `%(asctime)s - %(name)s - %(levelname)s - %(message)s` | Log message format |

## Environment-Specific Configurations

### Development
```bash
DASHBOARD_ENV=development
DASHBOARD_DEBUG=true
DASHBOARD_HOST=0.0.0.0
DASHBOARD_PORT=5000
DASHBOARD_LOG_LEVEL=DEBUG
```

### Production
```bash
DASHBOARD_ENV=production
DASHBOARD_DEBUG=false
DASHBOARD_HOST=127.0.0.1
DASHBOARD_PORT=5000
DASHBOARD_SECRET_KEY=your-super-secret-key-here
DASHBOARD_LOG_LEVEL=WARNING
```

## Configuration Validation

The dashboard automatically validates your configuration and shows warnings for potential issues:

- **Security warnings** for development settings in production
- **Port warnings** for privileged ports
- **Host warnings** for open access in debug mode

## Examples

### Local Development
```bash
# .env file
DASHBOARD_ENV=development
DASHBOARD_DEBUG=true
DASHBOARD_PORT=5000
```

### Production Behind Proxy
```bash
# .env file
DASHBOARD_ENV=production
DASHBOARD_HOST=127.0.0.1
DASHBOARD_PORT=5000
DASHBOARD_SECRET_KEY=your-production-secret-key
DASHBOARD_LOG_LEVEL=WARNING
```

### Custom Configuration
```bash
# .env file
DASHBOARD_ENV=development
DASHBOARD_PORT=8080
DASHBOARD_DEFAULT_BUCKET_COUNT=50
DASHBOARD_CHART_HEIGHT=600
DASHBOARD_LOG_LEVEL=DEBUG
```

## Running with Configuration

The dashboard automatically detects and uses your configuration:

```bash
# Uses .env file if present, otherwise defaults
python3 run_dashboard.py

# Override specific settings
DASHBOARD_PORT=8080 python3 run_dashboard.py

# Production deployment
DASHBOARD_ENV=production DASHBOARD_SECRET_KEY=secret python3 run_dashboard.py
```

## Configuration Tips

1. **Never commit .env files** - they contain sensitive information
2. **Use different configurations** for development, staging, and production
3. **Set strong secret keys** in production environments
4. **Restrict host access** in production (use `127.0.0.1` or specific IPs)
5. **Adjust log levels** based on environment needs
6. **Test configurations** before deploying to production
