#!/usr/bin/env python3
"""
Launcher script for the FAQ Bucket Results Dashboard
"""

import os
import sys
import subprocess
from pathlib import Path
from typing import NoReturn

def check_dependencies() -> bool:
    """Check if required packages are installed."""
    try:
        import flask
        import pandas
        import reportlab
        return True
    except ImportError as e:
        print(f"Missing dependency: {e}")
        print("Please install required packages with: pip install -r ../requirements.txt")
        return False

def show_config_info() -> None:
    """Show current configuration information."""
    try:
        # Import config after ensuring we're in the right directory
        sys.path.append('.')
        from config import config
        
        print("Dashboard Configuration:")
        print(f"  Environment: {os.getenv('DASHBOARD_ENV', 'development')}")
        print(f"  Host: {config.HOST}")
        print(f"  Port: {config.PORT}")
        print(f"  Debug Mode: {config.DEBUG}")
        print(f"  Log Level: {config.LOG_LEVEL}")
        print(f"  Max File Size: {config.MAX_CONTENT_LENGTH // (1024*1024)}MB")
        print()
        
        # Show any configuration warnings
        warnings = config.validate_config()
        if warnings:
            print("Configuration Warnings:")
            for warning in warnings:
                print(f"  ⚠️  {warning}")
            print()
            
    except ImportError:
        print("Could not load configuration - using defaults")
        print()

def main() -> NoReturn:
    """Main launcher function."""
    print("FAQ Bucket Results Dashboard")
    print("=" * 40)
    
    # Check dependencies
    if not check_dependencies():
        sys.exit(1)
    
    # Get the dashboard directory
    dashboard_dir: Path = Path(__file__).parent
    os.chdir(dashboard_dir)
    
    # Check if app.py exists
    if not Path("app.py").exists():
        print("Error: app.py not found in dashboard directory")
        sys.exit(1)
    
    # Show configuration information
    show_config_info()
    
    print("Starting dashboard...")
    print("Dashboard will be available at: http://localhost:5000")
    print("Press Ctrl+C to stop the dashboard")
    print()
    print("Configuration Tips:")
    print("  - Set DASHBOARD_ENV=production for production use")
    print("  - Set DASHBOARD_SECRET_KEY for production security")
    print("  - Copy env.example to .env to customize settings")
    print()
    
    try:
        # Run the Flask app
        subprocess.run([sys.executable, "app.py"])
    except KeyboardInterrupt:
        print("\nDashboard stopped.")
    except Exception as e:
        print(f"Error running dashboard: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
