#!/usr/bin/env python3
"""
Configuration management for the FAQ Bucket Dashboard.
"""

import os
from typing import Optional, List, Dict, Any

class Config:
    """Configuration class for the dashboard application."""
    
    # Flask Configuration
    SECRET_KEY: str = os.getenv('DASHBOARD_SECRET_KEY', 'dev-secret-key-change-in-production')
    DEBUG: bool = os.getenv('DASHBOARD_DEBUG', 'false').lower() == 'true'
    
    # Server Configuration
    HOST: str = os.getenv('DASHBOARD_HOST', '0.0.0.0')
    PORT: int = int(os.getenv('DASHBOARD_PORT', '5000'))
    
    # File Upload Configuration
    MAX_CONTENT_LENGTH: int = int(os.getenv('DASHBOARD_MAX_FILE_SIZE_MB', '16')) * 1024 * 1024
    
    # Chart Configuration
    DEFAULT_BUCKET_COUNT: int = int(os.getenv('DASHBOARD_DEFAULT_BUCKET_COUNT', '25'))
    MAX_BUCKET_COUNT: int = int(os.getenv('DASHBOARD_MAX_BUCKET_COUNT', '100'))
    CHART_HEIGHT: int = int(os.getenv('DASHBOARD_CHART_HEIGHT', '400'))
    
    # Pagination Configuration
    DEFAULT_PAGE_SIZE: int = int(os.getenv('DASHBOARD_DEFAULT_PAGE_SIZE', '20'))
    MAX_PAGE_SIZE: int = int(os.getenv('DASHBOARD_MAX_PAGE_SIZE', '100'))
    
    # Logging Configuration
    LOG_LEVEL: str = os.getenv('DASHBOARD_LOG_LEVEL', 'INFO')
    LOG_FORMAT: str = os.getenv('DASHBOARD_LOG_FORMAT', 
                               '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    
    # Security Configuration
    ALLOWED_HOSTS: List[str] = os.getenv('DASHBOARD_ALLOWED_HOSTS', '*').split(',')
    
    # Data Configuration
    REQUIRED_FILES: List[str] = [
        'faq_bucket_summary.csv',
        'faq_bucket_canonical_qna.csv', 
        'faq_bucket_assignments.csv'
    ]
    
    # Similarity Filter Configuration
    SIMILARITY_RANGES: Dict[str, Dict[str, Any]] = {
        '0.6-0.7': {'min': 0.6, 'max': 0.7, 'color': 'rgba(255, 99, 132, 0.8)'},
        '0.7-0.8': {'min': 0.7, 'max': 0.8, 'color': 'rgba(255, 165, 0, 0.8)'},
        '0.8-0.9': {'min': 0.8, 'max': 0.9, 'color': 'rgba(255, 205, 86, 0.8)'},
        '0.9-1.0': {'min': 0.9, 'max': 1.0, 'color': 'rgba(54, 162, 235, 0.8)'}
    }
    
    @classmethod
    def get_flask_config(cls) -> Dict[str, Any]:
        """Get Flask-specific configuration dictionary."""
        return {
            'SECRET_KEY': cls.SECRET_KEY,
            'DEBUG': cls.DEBUG,
            'MAX_CONTENT_LENGTH': cls.MAX_CONTENT_LENGTH
        }
    
    @classmethod
    def validate_config(cls) -> List[str]:
        """Validate configuration and return any warnings."""
        warnings: List[str] = []
        
        if cls.DEBUG and cls.HOST == '0.0.0.0':
            warnings.append("Warning: Running in debug mode with host 0.0.0.0 (accessible from any IP)")
        
        if cls.SECRET_KEY == 'dev-secret-key-change-in-production':
            warnings.append("Warning: Using default secret key. Set DASHBOARD_SECRET_KEY in production")
        
        if cls.PORT < 1024:
            warnings.append("Warning: Using privileged port (< 1024). Consider using port 5000+")
        
        return warnings

class DevelopmentConfig(Config):
    """Development-specific configuration."""
    DEBUG: bool = True
    LOG_LEVEL: str = 'DEBUG'

class ProductionConfig(Config):
    """Production-specific configuration."""
    DEBUG: bool = False
    LOG_LEVEL: str = 'WARNING'
    
    # Override defaults for production
    HOST: str = os.getenv('DASHBOARD_HOST', '127.0.0.1')  # More restrictive default
    SECRET_KEY: str = os.getenv('DASHBOARD_SECRET_KEY')  # Must be set in production
    
    @classmethod
    def validate_config(cls) -> List[str]:
        """Validate production configuration."""
        warnings: List[str] = super().validate_config()
        
        if not cls.SECRET_KEY or cls.SECRET_KEY == 'dev-secret-key-change-in-production':
            warnings.append("ERROR: DASHBOARD_SECRET_KEY must be set in production")
        
        if cls.HOST == '0.0.0.0':
            warnings.append("Warning: Production host is 0.0.0.0 (accessible from any IP)")
        
        return warnings

def get_config() -> Config:
    """Get the appropriate configuration based on environment."""
    env: str = os.getenv('DASHBOARD_ENV', 'development').lower()
    
    if env == 'production':
        return ProductionConfig()
    else:
        return DevelopmentConfig()

# Global config instance
config: Config = get_config()
