# FAQ Bucketer

Cluster Zendesk ticket Q&A into **FAQ-ready topic buckets** using local embeddings and unsupervised clustering.
Designed for building self-serve documentation from real support tickets.

## Features
- **Preprocessing**: Extract Q&A from complex CSVs with embedded JSON data
- **Flexible Input**: Handles both simple Q&A format and complex multi-column CSVs
- Parses Q&A from a `qna_content` column in CSV (one row per ticket), **or** from JSON-embedded data
- Embeds questions using:
  - Local Ollama model (`nomic-embed-text` recommended), **or**
  - Deterministic mock embeddings (for offline testing)
- Dynamically clusters related questions (HDBSCAN if available, Agglomerative fallback)
- Labels each bucket with top keywords (c-TF-IDF style)
- Selects representative Q&A for each bucket
- **Optional:** Synthesizes one canonical answer per bucket via local Ollama LLM (stateless, per bucket)
- Exports:
  - `faq_bucket_summary.csv` (buckets + per-ticket assignments)
  - `faq_bucket_canonical_qna.csv` (representative Q&A per bucket)
  - `faq_bucket_assignments.csv` (question-to-bucket mapping)
  - `run_report.md` (diagnostics, cluster stats)

## Requirements
- Python 3.9+
- [Ollama](https://ollama.ai/) running locally for embedding/synthesis modes
- Dependencies:
  ```bash
  pip install -r requirements.txt
  ```

## Dashboard

The project includes an interactive web dashboard for analyzing clustering results:

- **Interactive Analysis**: Browse buckets, view questions, and analyze canonical answers
- **Visualizations**: Charts showing bucket sizes and similarity distributions
- **PDF Reports**: Generate comprehensive reports for analysis
- **Easy Setup**: Run with `python dashboard/run_dashboard.py` after clustering

See [dashboard/README.md](dashboard/README.md) for detailed usage instructions.

## Quickstart

### 1. Setup
```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

### 2. For Complex CSVs (Recommended Workflow)

If you have a complex CSV with embedded JSON data (like Zendesk exports with many columns):

#### Step 2a: Preprocess Complex CSV
```bash
python3 faq_bucketer.py \
  --csv /path/to/complex_zendesk_export.csv \
  --preprocess \
  --clean-output ./clean_qa_data.csv
```

This will:
- Scan all columns for JSON data containing questions
- Extract questions and answers from JSON arrays
- Create a clean 2-column CSV (question, answer)
- Handle escaped quotes and complex data formats

#### Step 2b: Run Clustering on Clean Data
```bash
python3 faq_bucketer.py \
  --csv ./clean_qa_data.csv \
  --embedder ollama \
  --embedder-model nomic-embed-text \
  --outdir ./out_clustered
```

### 3. For Simple CSVs

If you already have a simple CSV with Q&A format:

```bash
python3 faq_bucketer.py \
  --csv ./simple_qa_data.csv \
  --embedder ollama \
  --embedder-model nomic-embed-text \
  --outdir ./out_simple
```

### 4. Test Run (Mock Embeddings)

For testing without Ollama:
```bash
python3 faq_bucketer.py \
  --csv ./clean_qa_data.csv \
  --embedder mock \
  --outdir ./out_test
```

### 5. (Optional) Synthesize Canonical Answers
```bash
ollama pull mistral:latest

python3 faq_bucketer.py \
  --csv ./clean_qa_data.csv \
  --embedder ollama \
  --embedder-model nomic-embed-text \
  --synthesize \
  --gen-model mistral:latest \
  --outdir ./out_with_synthesis
```

## CLI Options
```
--csv PATH                Path to CSV with Q&A data
--outdir DIR              Output directory (default: ./out)
--embedder {mock,ollama}  Embedding backend
--embedder-model NAME     Ollama embedding model (default: nomic-embed-text)
--prefer-hdbscan          Prefer HDBSCAN if installed (default: on)
--no-prefer-hdbscan       Disable HDBSCAN preference (fallback to Agglomerative)
--min-cluster-size N      Min cluster size (default: 8)
--min-samples N           HDBSCAN min_samples (default: auto)
--synthesize              Generate canonical answers per bucket (requires Ollama)
--gen-model NAME          Ollama model for synthesis (default: mistral:latest)
--seed N                  Random seed (default: 42)
--preprocess              Preprocess complex CSV with JSON data into clean Q&A format
--clean-output PATH       Output path for cleaned CSV (when using --preprocess)
```

## Data Format Support

### Complex CSV Format (Zendesk exports)
- Multiple columns with embedded JSON data
- JSON arrays containing question/answer objects
- Example: `[{"question": "How do I...", "answer": "You should..."}]`
- Use `--preprocess` to extract and clean

### Simple CSV Format
- 2 columns: `question`, `answer`
- Or single column: `qna_content` with "Q: question A: answer" format

## Troubleshooting
- **Missing `qna_content`**: Check your CSV headers; the script lists available columns if not found.
- **Complex data format**: Use `--preprocess` to extract JSON data from complex CSVs.
- **Ollama errors**: Ensure `ollama serve` is running and the model is pulled locally.
- **Empty embeddings**: Make sure you're using the latest Ollama version with `/api/embed` endpoint.
- **Sparse or noisy clusters**: Increase `--min-cluster-size` or try Agglomerative mode (`--no-prefer-hdbscan`).
- **Synthesis fails**: Falls back to medoid answer; check model choice and Ollama logs.

## License
MIT
