#!/usr/bin/env python3
"""
FAQ Bucketer — from Zendesk ticket QnA to FAQ-ready buckets.

Features
- Robust CSV load with helpful errors
- Heuristic Q/A parsing per row (from 'qna_content')
- Embeddings via Ollama (local) OR deterministic 'mock' mode for testing
- Dimensionality reduction (PCA), clustering (HDBSCAN if installed; fallback to Agglomerative)
- Bucket quality metrics (median intra-cluster cosine)
- Bucket labels via c-TF-IDF-style keywords
- Canonical answer per bucket: medoid by default; optional synthesis via Ollama
- Sortable drill-down outputs: Excel with 'buckets' and 'assignments' sheets
- Run report with diagnostics
- Clear, actionable error messages

Usage
------
Basic (mock embeddings on sample file):
    python faq_bucketer.py --csv ./zendesk_ticket_qna_sample.csv --embedder mock

Local Ollama embeddings:
    python faq_bucketer.py --csv /path/to/full.csv --embedder ollama --embedder-model nomic-embed-text

Add synthesis with local Ollama:
    python faq_bucketer.py --csv /path/to/full.csv --embedder ollama --synthesize --gen-model mistral:latest

Outputs go to ./out/ by default. Use --outdir to change.
"""
import argparse
import hashlib
import json
import math
import os
import re
import sys
import time
from dataclasses import dataclass
from typing import List, Tuple, Optional, Dict

import numpy as np
import pandas as pd

try:
    import requests
    HAVE_REQUESTS = True
except Exception:
    HAVE_REQUESTS = False

try:
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity
    from sklearn.decomposition import PCA
    from sklearn.cluster import AgglomerativeClustering
    SKLEARN_OK = True
except Exception:
    SKLEARN_OK = False

try:
    import hdbscan  # type: ignore
    HAVE_HDBSCAN = True
except Exception:
    HAVE_HDBSCAN = False

class UserError(Exception):
    pass

def log(msg: str):
    print(f"[faq-bucketer] {msg}", flush=True)

def ensure_dir(path: str):
    os.makedirs(path, exist_ok=True)

def preprocess_complex_csv(csv_path: str, output_path: str) -> str:
    """
    Preprocess complex CSV with JSON data into clean Q&A format.
    
    Args:
        csv_path: Path to complex CSV with many columns
        output_path: Path to save clean 2-column CSV
        
    Returns:
        Path to the cleaned CSV file
    """
    log(f"Preprocessing complex CSV: {csv_path}")
    
    # Load the complex CSV
    try:
        df = pd.read_csv(csv_path)
    except Exception as e:
        raise UserError(f"Failed to read CSV '{csv_path}': {e}")
    
    log(f"Loaded CSV with {df.shape[0]} rows and {df.shape[1]} columns")
    
    # Find all cells containing JSON data with questions
    questions_answers = []
    
    for row_idx, row in df.iterrows():
        for col_idx, cell_value in enumerate(row):
            if pd.isna(cell_value) or str(cell_value).lower() in ['nan', 'null', '']:
                continue
                
            cell_str = str(cell_value).strip()
            
            # Try to parse as JSON and extract questions
            try:
                import json
                # Handle escaped quotes in CSV - replace "" with "
                cell_str_clean = cell_str.replace('""', '"')
                data = json.loads(cell_str_clean)
                
                if isinstance(data, list) and len(data) > 0:
                    # Found JSON array, extract questions
                    for item in data:
                        if isinstance(item, dict) and "question" in item:
                            question = item.get("question", "").strip()
                            answer = item.get("answer", "").strip()
                            
                            if question:  # Only add if we have a question
                                questions_answers.append({
                                    "question": question,
                                    "answer": answer if answer else "[No answer provided]",
                                    "source_row": row_idx,
                                    "source_col": df.columns[col_idx]
                                })
                                
            except (json.JSONDecodeError, TypeError) as e:
                # Not valid JSON, skip
                continue
    
    log(f"Found {len(questions_answers)} questions in JSON data")
    
    if not questions_answers:
        raise UserError("No valid JSON questions found in the CSV. Check your data format.")
    
    # Create clean DataFrame
    clean_df = pd.DataFrame(questions_answers)
    
    # Save clean CSV with just question and answer columns
    clean_df[["question", "answer"]].to_csv(output_path, index=False)
    
    log(f"Saved clean CSV to: {output_path}")
    log(f"Clean CSV has {len(clean_df)} rows with questions")
    
    # Show sample of extracted data
    log("Sample extracted questions:")
    for i, row in clean_df.head(3).iterrows():
        log(f"  {i+1}. Q: {row['question'][:80]}...")
        if row['answer'] != "[No answer provided]":
            log(f"     A: {row['answer'][:80]}...")
    
    return output_path

def safe_lower(s: Optional[str]) -> str:
    return (s or "").strip()

def human_ts() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")

def load_csv(csv_path: str) -> pd.DataFrame:
    if not os.path.exists(csv_path):
        raise UserError(f"CSV not found at '{csv_path}'. Double-check the path.")
    try:
        df = pd.read_csv(csv_path)
    except Exception as e:
        raise UserError(f"Failed to read CSV '{csv_path}'. Error: {e}")
    if df.empty:
        raise UserError("The CSV loaded but appears empty. Ensure it has rows.")
    
    # Debug: Show available columns
    print(f"DEBUG: Available columns: {list(df.columns)}")
    print(f"DEBUG: CSV shape: {df.shape}")
    
    # Check if this is a clean 2-column format (question, answer)
    if len(df.columns) == 2 and 'question' in df.columns and 'answer' in df.columns:
        log("Detected clean 2-column Q&A format")
        # Rename to match expected format
        df = df.rename(columns={"question": "question_text", "answer": "answer_text"})
        # Add qna_content column for compatibility
        df["qna_content"] = df["question_text"] + " | " + df["answer_text"]
        return df
    
    # Original complex format handling
    cols_lower = {c.lower(): c for c in df.columns}
    if "qna_content" in cols_lower:
        qcol = cols_lower["qna_content"]
    else:
        raise UserError(
            "Column 'qna_content' not found (case-insensitive). "
            f"Available columns: {list(df.columns)}. "
            "Please ensure your CSV has a 'qna_content' column containing the ticket Q&A, "
            "or use --preprocess to convert your complex CSV to clean format."
        )
    
    # Debug: Show sample content from qna_content column
    print(f"DEBUG: Sample qna_content values:")
    for i, val in enumerate(df[qcol].head(3)):
        print(f"  Row {i}: {str(val)[:100]}...")
    
    df[qcol] = df[qcol].astype(str).fillna("")
    df = df.rename(columns={qcol: "qna_content"})
    return df

def split_qna(text: str) -> Tuple[str, str]:
    """Parse Q&A from text. Handles both simple Q: A: format and JSON format."""
    if not text or text.lower() in ['nan', 'null', '']:
        return "", ""
    
    # Try to parse as JSON first (for your data format)
    try:
        import json
        data = json.loads(text)
        if isinstance(data, list) and len(data) > 0:
            # Extract questions from JSON array
            questions = []
            for item in data:
                if isinstance(item, dict) and "question" in item:
                    questions.append(item["question"])
            
            if questions:
                # Join multiple questions with separator
                question_text = " | ".join(questions)
                # For now, use a placeholder answer since JSON doesn't have answers
                answer_text = "[Answer not provided in JSON format]"
                return question_text, answer_text
    except (json.JSONDecodeError, TypeError):
        # Not JSON, fall back to simple text parsing
        pass
    
    # Fallback: try to parse simple Q: A: format
    text = text.strip()
    if not text:
        return "", ""
    
    # Look for Q: and A: patterns
    q_match = re.search(r'Q:\s*(.*?)(?=\s*A:|$)', text, re.IGNORECASE | re.DOTALL)
    a_match = re.search(r'A:\s*(.*?)(?=\s*Q:|$)', text, re.IGNORECASE | re.DOTALL)
    
    question = q_match.group(1).strip() if q_match else ""
    answer = a_match.group(1).strip() if a_match else ""
    
    return question, answer

def mock_embed(texts: List[str], dim: int = 384, seed: int = 42) -> np.ndarray:
    rng = np.random.default_rng(seed)
    vecs = []
    for t in texts:
        h = int(hashlib.sha256(t.encode("utf-8")).hexdigest(), 16) % (2**32 - 1)
        local_rng = np.random.default_rng(h ^ seed)
        v = local_rng.standard_normal(dim)
        v = v / (np.linalg.norm(v) + 1e-9)
        vecs.append(v)
    return np.vstack(vecs)

def ollama_embed(texts: List[str], model: str = "nomic-embed-text",
                 url: str = "http://localhost:11434/api/embed",
                 batch_size: int = 64, timeout: int = 60) -> np.ndarray:
    if not HAVE_REQUESTS:
        raise UserError("The 'requests' package is required for Ollama embeddings. Install it and retry.")
    if not texts:
        return np.zeros((0, 384), dtype=np.float32)

    all_vecs = []
    for i in range(0, len(texts), batch_size):
        batch = texts[i:i+batch_size]
        try:
            resp = requests.post(url, json={"model": model, "input": batch}, timeout=timeout)
        except Exception as e:
            raise UserError(f"Failed connecting to Ollama at {url}. Is the daemon running? Error: {e}")

        if resp.status_code != 200:
            try:
                err = resp.json()
            except Exception:
                err = resp.text
            raise UserError(f"Ollama embeddings API error (HTTP {resp.status_code}): {err}")

        data = resp.json()
        # Handle the correct /api/embed response format:
        # {"embeddings": [[...], [...]]}
        vecs = None
        if isinstance(data, dict):
            if "embeddings" in data and isinstance(data["embeddings"], list):
                vecs = data["embeddings"]
        
        # Debug: Log what we're getting from Ollama
        print(f"DEBUG: Ollama response keys: {list(data.keys())}")
        if "embeddings" in data:
            print(f"DEBUG: embeddings type: {type(data['embeddings'])}, length: {len(data['embeddings']) if isinstance(data['embeddings'], list) else 'not list'}")
        
        if not vecs:
            raise UserError(f"Unexpected response from Ollama embeddings API: keys={list(data.keys())}")
        
        print(f"DEBUG: Extracted vecs length: {len(vecs)}")
        if vecs and len(vecs) > 0:
            print(f"DEBUG: First vector length: {len(vecs[0]) if isinstance(vecs[0], list) else 'not list'}")
        
        all_vecs.extend(vecs)

    arr = np.array(all_vecs, dtype=np.float32)
    # Normalize for cosine similarity
    norms = np.linalg.norm(arr, axis=1, keepdims=True) + 1e-12
    arr = arr / norms
    return arr
    
from dataclasses import dataclass

@dataclass
class ClusterResult:
    labels: np.ndarray
    reduced: Optional[np.ndarray]
    algo: str

def cosine_median_intra(cluster_vecs: np.ndarray) -> float:
    if cluster_vecs.shape[0] <= 1:
        return 1.0
    from sklearn.metrics.pairwise import cosine_similarity
    sim = cosine_similarity(cluster_vecs)
    tril = np.tril_indices_from(sim, k=-1)
    vals = sim[tril]
    return float(np.median(vals)) if vals.size else 1.0

def cluster_vectors(vectors: np.ndarray,
                    prefer_hdbscan: bool = True,
                    min_cluster_size: int = 8,
                    min_samples: Optional[int] = None) -> ClusterResult:
    if not SKLEARN_OK:
        raise UserError("scikit-learn is required for clustering. Please install requirements.txt and retry.")
    
    # For very small datasets, adjust min_cluster_size to be more reasonable
    effective_min_size = min(min_cluster_size, max(2, vectors.shape[0] // 2))
    
    if vectors.shape[0] < effective_min_size * 2:
        labels = np.zeros((vectors.shape[0],), dtype=int)
        return ClusterResult(labels=labels, reduced=None, algo="single-bucket")

    from sklearn.decomposition import PCA
    pca = PCA(n_components=min(50, vectors.shape[1]))
    reduced = pca.fit_transform(vectors)

    if prefer_hdbscan and HAVE_HDBSCAN:
        clusterer = hdbscan.HDBSCAN(min_cluster_size=effective_min_size,
                                    min_samples=min_samples,
                                    metric='euclidean',
                                    cluster_selection_method='eom')
        labels = clusterer.fit_predict(reduced)
        algo = "hdbscan"
    else:
        from sklearn.cluster import AgglomerativeClustering
        from sklearn.metrics.pairwise import euclidean_distances
        sample_idx = np.random.choice(reduced.shape[0], size=min(500, reduced.shape[0]), replace=False)
        sample = reduced[sample_idx]
        d = euclidean_distances(sample)
        tril = np.tril_indices_from(d, k=-1)
        distances = d[tril]
        thresh = float(np.percentile(distances, 40))
        clusterer = AgglomerativeClustering(n_clusters=None, distance_threshold=thresh)
        labels = clusterer.fit_predict(reduced)
        algo = f"agglomerative(thr={thresh:.3f})"

    return ClusterResult(labels=labels, reduced=reduced, algo=algo)

def label_clusters(texts: List[str], labels: np.ndarray, top_k: int = 4) -> Dict[int, str]:
    if not SKLEARN_OK:
        return {int(l): f"bucket_{l}" for l in np.unique(labels) if l != -1}
    
    # Validate input lengths
    if len(texts) != len(labels):
        raise UserError(f"label_clusters: Length mismatch - {len(texts)} texts vs {len(labels)} labels")
    
    from sklearn.feature_extraction.text import TfidfVectorizer
    df = pd.DataFrame({"label": labels, "text": texts})
    labels_unique = [int(l) for l in sorted(df["label"].unique()) if l != -1]
    out: Dict[int, str] = {}
    for lab in labels_unique:
        docs = df[df["label"] == lab]["text"].tolist()
        if not docs:
            out[lab] = f"bucket_{lab}"
            continue
        try:
            vec = TfidfVectorizer(stop_words="english", ngram_range=(1,2), min_df=1)
            X = vec.fit_transform(docs)
            mean_scores = np.asarray(X.mean(axis=0)).ravel()
            inds = mean_scores.argsort()[::-1][:top_k]
            vocab = np.array(vec.get_feature_names_out())[inds]
            label = ", ".join(vocab)
            out[lab] = label
        except Exception:
            out[lab] = f"bucket_{lab}"
    return out

def medoid_index(vectors: np.ndarray, idxs: np.ndarray) -> int:
    if idxs.size == 1:
        return int(idxs[0])
    from sklearn.metrics.pairwise import cosine_similarity
    sub = vectors[idxs]
    centroid = sub.mean(axis=0, keepdims=True)
    sim = cosine_similarity(sub, centroid).ravel()
    rel = int(np.argmax(sim))
    return int(idxs[rel])

def synthesize_answer(snippets: List[str], model: str = "mistral:latest",
                      url: str = "http://localhost:11434/api/generate",
                      max_out_tokens: int = 500,
                      temperature: float = 0.2,
                      num_ctx: int = 8192) -> str:
    if not HAVE_REQUESTS:
        raise UserError("The 'requests' package is required for Ollama synthesis. Install it and retry.")
    prompt = (
        "SYSTEM:\\nYou write concise, generalizable FAQ answers for a SaaS security product. "
        "Remove tenant-specific details, ticket IDs, and private data. Provide broad steps and key checks."
        "\\n\\nUSER:\\nUsing the following short Q/A snippets, produce one canonical answer that solves the majority case. "
        "Include: a brief overview, step-by-step guidance, and a short troubleshooting section. Be concise.\\n---\\n"
        + "\\n\\n---\\n".join(snippets[:12]) + "\\n---\\n"
    )
    payload = {
        "model": model,
        "prompt": prompt,
        "options": {"temperature": temperature, "num_ctx": num_ctx},
    }
    try:
        import requests
        resp = requests.post(url, json=payload, timeout=120)
    except Exception as e:
        raise UserError(f"Failed connecting to Ollama for synthesis at {url}. Is it running? Error: {e}")
    if resp.status_code != 200:
        try:
            err = resp.json()
        except Exception:
            err = resp.text
        raise UserError(f"Ollama synthesis API error (HTTP {resp.status_code}): {err}")
    data = resp.json()
    if "response" not in data:
        raise UserError(f"Unexpected response from Ollama synthesis API: keys={list(data.keys())}")
    text = data["response"]
    if not safe_lower(text):
        raise UserError("Synthesis produced an empty response. Try a different model or adjust parameters.")
    return text.strip()

def run_pipeline(csv_path: str,
                 outdir: str,
                 embedder: str = "mock",
                 embedder_model: str = "nomic-embed-text",
                 prefer_hdbscan: bool = True,
                 min_cluster_size: int = 8,
                 min_samples: Optional[int] = None,
                 synthesize: bool = False,
                 gen_model: str = "mistral:latest",
                 seed: int = 42) -> Dict:
    np.random.seed(seed)
    ensure_dir(outdir)
    start_ts = human_ts()
    report_lines = [f"# FAQ Bucketer Run Report\\n\\nStarted: {start_ts}\\n"]

    df = load_csv(csv_path)
    report_lines.append(f"- Rows loaded: {len(df)}")

    # Check if we already have clean question/answer columns
    if "question_text" in df.columns and "answer_text" in df.columns:
        log("Using pre-existing question_text and answer_text columns")
        qs = df["question_text"].astype(str).tolist()
        ans = df["answer_text"].astype(str).tolist()
    else:
        # Original parsing logic
        qs, ans = [], []
        for t in df["qna_content"].astype(str).tolist():
            q, a = split_qna(t)
            qs.append(q)
            ans.append(a)
        df["question_text"] = qs
        df["answer_text"] = ans

    mask_nonempty = df["question_text"].str.len() > 0
    kept = int(mask_nonempty.sum())
    if kept == 0:
        raise UserError("No non-empty questions could be parsed from 'qna_content'. Check your data format.")
    if kept < len(df):
        report_lines.append(f"- Dropped {len(df) - kept} rows with empty/invalid questions.")
    df = df[mask_nonempty].reset_index(drop=True)

    q_texts = df["question_text"].tolist()
    if embedder == "mock":
        vectors = mock_embed(q_texts, dim=384, seed=seed)
        report_lines.append("- Embeddings: mock (deterministic hashing)")
    elif embedder == "ollama":
        vectors = ollama_embed(q_texts, model=embedder_model)
        report_lines.append(f"- Embeddings: Ollama model '{embedder_model}'")
    else:
        raise UserError(f"Unknown embedder '{embedder}'. Use 'mock' or 'ollama'.")

    clres = cluster_vectors(vectors, prefer_hdbscan=prefer_hdbscan,
                            min_cluster_size=min_cluster_size, min_samples=min_samples)
    labels = clres.labels
    algo = clres.algo
    
    # Validate that labels length matches the filtered DataFrame
    if len(labels) != len(df):
        raise UserError(f"Length mismatch: labels array has {len(labels)} elements but filtered DataFrame has {len(df)} rows. This suggests a bug in the clustering or filtering logic.")
    
    report_lines.append(f"- Clustering algorithm: {algo}")
    n_noise = int((labels == -1).sum())
    n_clusters = len(set(labels)) - (1 if -1 in labels else 0)
    report_lines.append(f"- Clusters formed: {n_clusters} (noise items: {n_noise})")

    df["bucket_id"] = labels
    bucket_rows = []
    assignments = []
    
    # Ensure we're passing the correct lengths to label_clusters
    question_texts = df["question_text"].tolist()
    if len(question_texts) != len(labels):
        raise UserError(f"Length mismatch in label_clusters call: {len(question_texts)} texts vs {len(labels)} labels")
    
    label_names = label_clusters(question_texts, labels)

    from sklearn.metrics.pairwise import cosine_similarity

    for b in sorted(set(labels)):
        if b == -1:
            continue
        idxs = np.where(labels == b)[0]
        n_items = int(idxs.size)
        med = medoid_index(vectors, idxs)
        sub = vectors[idxs]
        centroid = sub.mean(axis=0, keepdims=True)
        sim = cosine_similarity(sub, centroid).ravel()
        intra = float(np.median(np.tril(np.matmul(sub, sub.T), k=-1)[np.tril_indices(n_items, -1)])) if n_items>1 else 1.0
        label_name = label_names.get(int(b), f"bucket_{b}")

        rep_q = df.loc[med, "question_text"]
        if synthesize:
            order = np.argsort(sim)[::-1]
            top = idxs[order[:12]]
            snippets = []
            for rid in top:
                q = df.loc[rid, "question_text"]
                a = df.loc[rid, "answer_text"]
                snippets.append(f"Q: {q}\\nA: {a}")
            try:
                canon_a = synthesize_answer(snippets, model=gen_model)
            except UserError as e:
                log(f"WARNING: Synthesis failed for bucket {b}: {e}")
                canon_a = df.loc[med, "answer_text"]
        else:
            canon_a = df.loc[med, "answer_text"]

        bucket_rows.append({
            "bucket_id": int(b),
            "bucket_label": label_name,
            "n_items": n_items,
            "example_question": rep_q,
            "median_similarity": round(cosine_median_intra(vectors[idxs]), 4),
        })

        for rid in idxs:
            assignments.append({
                "bucket_id": int(b),
                "bucket_label": label_name,
                "question_text": df.loc[rid, "question_text"],
                "answer_text": df.loc[rid, "answer_text"],
                "qna_content": df.loc[rid, "qna_content"],
                "source_row_index": int(rid),
            })

    canonical_rows = []
    seen = set()
    for row in bucket_rows:
        b = row["bucket_id"]
        if b in seen:
            continue
        seen.add(b)
        idxs = np.where(labels == b)[0]
        med = medoid_index(vectors, idxs)
        if synthesize:
            sub = vectors[idxs]
            centroid = sub.mean(axis=0, keepdims=True)
            sim = cosine_similarity(sub, centroid).ravel()
            order = np.argsort(sim)[::-1]
            top = idxs[order[:12]]
            snippets = []
            for rid in top:
                q = df.loc[rid, "question_text"]
                a = df.loc[rid, "answer_text"]
                snippets.append(f"Q: {q}\\nA: {a}")
            try:
                canon_a = synthesize_answer(snippets, model=gen_model)
            except UserError:
                canon_a = df.loc[med, "answer_text"]
        else:
            canon_a = df.loc[med, "answer_text"]
        canonical_rows.append({
            "bucket_id": b,
            "bucket_label": row["bucket_label"],
            "representative_question": df.loc[med, "question_text"],
            "canonical_answer": canon_a
        })

    if n_noise > 0:
        idxs = np.where(labels == -1)[0]
        for rid in idxs:
            assignments.append({
                "bucket_id": -1,
                "bucket_label": "misc/noise",
                "question_text": df.loc[rid, "question_text"],
                "answer_text": df.loc[rid, "answer_text"],
                "qna_content": df.loc[rid, "qna_content"],
                "source_row_index": int(rid),
            })
        bucket_rows.append({
            "bucket_id": -1,
            "bucket_label": "misc/noise",
            "n_items": int(idxs.size),
            "example_question": df.loc[idxs[0], "question_text"] if idxs.size else "",
            "median_similarity": None
        })

    summary_path = os.path.join(outdir, "faq_bucket_summary.csv")
    canonical_path = os.path.join(outdir, "faq_bucket_canonical_qna.csv")
    report_path = os.path.join(outdir, "run_report.md")

    try:
        # Save summary data as CSV instead of Excel
        pd.DataFrame(bucket_rows).sort_values("n_items", ascending=False).to_csv(summary_path, index=False)
        pd.DataFrame(assignments).to_csv(os.path.join(outdir, "faq_bucket_assignments.csv"), index=False)
    except Exception as e:
        raise UserError(f"Failed writing CSV summary '{summary_path}'. Error: {e}")

    try:
        pd.DataFrame(canonical_rows).to_csv(canonical_path, index=False)
    except Exception as e:
        raise UserError(f"Failed writing canonical QnA CSV '{canonical_path}'. Error: {e}")

    big_buckets = sorted(bucket_rows, key=lambda r: (r['n_items'] or 0), reverse=True)[:10]
    report_lines.append("\\n## Top buckets by size\\n")
    for r in big_buckets:
        report_lines.append(f"- {r['bucket_id']} — {r['bucket_label']} (n={r['n_items']}, median_sim={r['median_similarity']})")

    report_lines.append("\\n## Notes\\n- 'misc/noise' contains outliers the clustering could not confidently group.")
    report_lines.append("- Consider re-running with different min_cluster_size if buckets are too small or too broad.")
    report_lines.append("- You can enable --synthesize once initial buckets look solid.")

    try:
        with open(report_path, "w", encoding="utf-8") as f:
            f.write("\\n".join(report_lines))
    except Exception as e:
        raise UserError(f"Failed writing run report '{report_path}'. Error: {e}")

    return {
        "summary_path": summary_path,
        "canonical_path": canonical_path,
        "report_path": report_path,
        "n_clusters": n_clusters,
        "n_noise": n_noise,
        "algo": algo
    }

def parse_args():
    import argparse
    ap = argparse.ArgumentParser(description="Cluster Zendesk Q&A into FAQ buckets.")
    ap.add_argument("--csv", required=True, help="Path to CSV with a 'qna_content' column.")
    ap.add_argument("--outdir", default="./out", help="Directory to write outputs.")
    ap.add_argument("--embedder", choices=["mock", "ollama"], default="mock", help="Embedding backend.")
    ap.add_argument("--embedder-model", default="nomic-embed-text", help="Ollama embedding model name.")
    ap.add_argument("--prefer-hdbscan", action="store_true", help="Prefer HDBSCAN if installed (default True).")
    ap.add_argument("--no-prefer-hdbscan", dest="prefer_hdbscan", action="store_false", help="Disable HDBSCAN preference.")
    ap.add_argument("--min-cluster-size", type=int, default=8, help="Minimum cluster size parameter.")
    ap.add_argument("--min-samples", type=int, default=None, help="HDBSCAN min_samples; default None lets it infer.")
    ap.add_argument("--synthesize", action="store_true", help="Generate canonical answers per bucket with Ollama.")
    ap.add_argument("--gen-model", default="mistral:latest", help="Ollama model for synthesis.")
    ap.add_argument("--seed", type=int, default=42, help="Random seed.")
    ap.add_argument("--preprocess", action="store_true", help="Preprocess complex CSV with JSON data into clean Q&A format.")
    ap.add_argument("--clean-output", default="./clean_qa_data.csv", help="Output path for cleaned CSV (when using --preprocess).")
    return ap.parse_args()

def main():
    args = parse_args()
    try:
        if args.preprocess:
            preprocess_complex_csv(args.csv, args.clean_output)
            log(f"Preprocessed CSV saved to: {args.clean_output}")
            sys.exit(0) # Exit after preprocessing

        res = run_pipeline(csv_path=args.csv,
                           outdir=args.outdir,
                           embedder=args.embedder,
                           embedder_model=args.embedder_model,
                           prefer_hdbscan=args.prefer_hdbscan,
                           min_cluster_size=args.min_cluster_size,
                           min_samples=args.min_samples,
                           synthesize=args.synthesize,
                           gen_model=args.gen_model,
                           seed=args.seed)
        log(f"Done. Clusters={res['n_clusters']} (noise={res['n_noise']}); algo={res['algo']}")
        log(f"Summary: {res['summary_path']}")
        log(f"Canonical QnA: {res['canonical_path']}")
        log(f"Report: {res['report_path']}")
        log(f"Assignments: {os.path.join(args.outdir, 'faq_bucket_assignments.csv')}")
    except UserError as e:
        log(f"ERROR: {e}")
        sys.exit(2)
    except Exception as e:
        log(f"UNEXPECTED ERROR: {e.__class__.__name__}: {e}")
        sys.exit(3)

if __name__ == "__main__":
    main()
